"""Prueba manual con inferencia REAL en Ollama o OpenAI; únicamente notas ficticias."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from src.providers.pipeline import analizar_nota


def obtener_texto(identificador: str) -> str:
    ruta = RAIZ / "data" / "clinical_notes" / "sample_notes.json"
    with ruta.open(encoding="utf-8") as archivo:
        notas = json.load(archivo)["notas"]
    for nota in notas:
        if nota["id"] == identificador:
            return nota["texto"]
    raise ValueError(f"No existe nota ficticia {identificador}")


def main() -> None:
    parser = argparse.ArgumentParser(description="CodificaMed: comparación de proveedores reales")
    parser.add_argument("--proveedor", choices=["ollama", "openai", "gemini"], default=None)
    grupo = parser.add_mutually_exclusive_group()
    grupo.add_argument("--texto", help="Nota ficticia entre comillas")
    grupo.add_argument("--nota", default="nota_003", help="ID en sample_notes.json")
    parser.add_argument("--sin-embeddings", action="store_true", help="Aislar el conector del modelo")
    args = parser.parse_args()
    try:
        texto = args.texto if args.texto is not None else obtener_texto(args.nota)
        resultado = analizar_nota(texto, proveedor=args.proveedor,
                                 usar_embeddings=not args.sin_embeddings)
    except (RuntimeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
    print(f"Proveedor: {resultado['proveedor']} | modelo: {resultado['modelo']}")
    print(f"Candidatos: {len(resultado['candidatos'])}")
    print(f"Tiempo total: {resultado['duracion_segundos']} s")
    for diagnostico in resultado["diagnosticos"]:
        print(f"[{diagnostico['estado']}] {diagnostico['codigo']} — {diagnostico['descripcion']}")
        print(f"  Evidencia literal: {diagnostico['evidencia']}")
    if not resultado["diagnosticos"]:
        print("El modelo se abstuvo o todas sus sugerencias fueron rechazadas.")
    for rechazo in resultado["rechazados"]:
        print(f"RECHAZADA {rechazo.get('codigo', '')}: {rechazo['motivo']}")
    print("AVISO: sugerencias académicas, no codificación clínica validada.")


if __name__ == "__main__":
    main()
