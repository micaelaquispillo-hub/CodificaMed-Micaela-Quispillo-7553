"""Repara caracteres mal codificados de las descripciones españolas del catálogo.

Solo modifica descripcion_es. Conserva códigos y demás columnas. Antes de escribir
crea copia de seguridad local del CSV original si existen modificaciones.
"""
from pathlib import Path
import csv
import os
import shutil
import tempfile

RUTA = Path(__file__).resolve().parents[1] / 'data' / 'cie10' / 'cie10_catalog.csv'
RESPALDO = RUTA.with_suffix('.csv.original.bak')


def reparar(texto: str) -> str:
    if not any(s in texto for s in ('Ã', 'Â', 'â')):
        return texto
    try:
        return texto.encode('latin-1').decode('utf-8')
    except UnicodeError as exc:
        raise ValueError(f'No se puede reparar automáticamente: {texto[:80]!r}') from exc


def main():
    if not RUTA.is_file():
        raise FileNotFoundError(f'No existe el catálogo: {RUTA}')
    with RUTA.open('r', encoding='utf-8', newline='') as archivo:
        lector = csv.DictReader(archivo)
        campos = lector.fieldnames
        if campos is None or not {'codigo', 'descripcion_es', 'descripcion_en'} <= set(campos):
            raise ValueError('Encabezados CSV inesperados; el archivo no se modificó.')
        filas = list(lector)

    total = len(filas)
    codigos = [fila['codigo'] for fila in filas]
    if len(set(codigos)) != total:
        raise ValueError('Hay códigos duplicados; el catálogo no se modificó.')

    cambios = 0
    for fila in filas:
        anterior = fila['descripcion_es']
        nuevo = reparar(anterior)
        if nuevo != anterior:
            fila['descripcion_es'] = nuevo
            cambios += 1

    if cambios:
        if not RESPALDO.exists():
            shutil.copy2(RUTA, RESPALDO)
        descriptor, temporal = tempfile.mkstemp(prefix='catalogo_', suffix='.csv', dir=RUTA.parent)
        try:
            with os.fdopen(descriptor, 'w', encoding='utf-8', newline='') as archivo:
                escritor = csv.DictWriter(archivo, fieldnames=campos)
                escritor.writeheader()
                escritor.writerows(filas)
            os.replace(temporal, RUTA)
        finally:
            if os.path.exists(temporal):
                os.remove(temporal)

    print(f'Catalogo: {total} codigos, {len(set(codigos))} unicos')
    print(f'Descripciones reparadas en esta ejecucion: {cambios}')
    print('Verificacion: OK (codigos sin cambios ni duplicados)')
    if cambios:
        print(f'Respaldo original: {RESPALDO.name}')


if __name__ == '__main__':
    main()
