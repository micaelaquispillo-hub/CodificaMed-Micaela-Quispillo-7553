"""Compara recuperación léxica y TF-IDF, sin ejecutar ningún LLM.

Las referencias solo se leen para MEDIR cobertura, nunca para generar candidatos.
Este corpus fue utilizado durante el desarrollo: resultados exploratorios.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from src.providers.pipeline import recuperar_candidatos  # noqa: E402


def evaluar(notas: list[dict], activar_tfidf: bool) -> tuple[int, int]:
    os.environ["CODIFICAMED_TFIDF_CATALOGO"] = "1" if activar_tfidf else "0"
    aciertos = 0
    total = 0
    for nota in notas:
        referencia = {e["codigo"] for e in nota["codigos_esperados"]
                      if e["estado"] == "confirmado"}
        lista = recuperar_candidatos(nota["texto"], usar_embeddings=False)
        recuperados = {c["codigo"] for c in lista}
        aciertos += len(referencia & recuperados)
        total += len(referencia)
        print(f"{nota['id']}: {len(referencia & recuperados)}/{len(referencia)} "
              f"disponibles | candidatos={len(lista)}")
    return aciertos, total


def main() -> None:
    ruta = RAIZ / "data" / "clinical_notes" / "sample_notes.json"
    with ruta.open(encoding="utf-8") as f:
        notas = json.load(f)["notas"]
    anterior = os.environ.get("CODIFICAMED_TFIDF_CATALOGO")
    try:
        print("=== LEXICO ORIGINAL ===")
        aciertos_base, total = evaluar(notas, False)
        print("\n=== LEXICO + TF-IDF CATALOGO ===")
        aciertos_nuevos, total2 = evaluar(notas, True)
        assert total == total2
        print(f"\nBASE: {aciertos_base}/{total} ({aciertos_base / total:.1%})")
        print(f"TF-IDF: {aciertos_nuevos}/{total} ({aciertos_nuevos / total:.1%})")
        print("AVISO: cobertura de candidatos; no es precision, recall ni F1 del LLM.")
    finally:
        if anterior is None:
            os.environ.pop("CODIFICAMED_TFIDF_CATALOGO", None)
        else:
            os.environ["CODIFICAMED_TFIDF_CATALOGO"] = anterior


if __name__ == "__main__":
    main()
