"""Prueba REAL de recuperación mediante embeddings; no asigna diagnósticos."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from src.retrieval.semantica import (MODELO_PREDETERMINADO,
                                    cargar_modelo, construir_o_cargar_indice)


def main() -> None:
    parser = argparse.ArgumentParser(description="Recuperación semántica de candidatos CIE-10")
    parser.add_argument("--consulta", default="Paciente con presión arterial elevada crónica")
    parser.add_argument("--modelo", default=MODELO_PREDETERMINADO)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--umbral", type=float, default=0.35)
    args = parser.parse_args()
    print("Cargando modelo real de embeddings:", args.modelo, flush=True)
    modelo = cargar_modelo(args.modelo)
    indice, en_cache = construir_o_cargar_indice(modelo, args.modelo)
    codigos = len({d["codigo"] for d in indice.documentos})
    print(f"Índice: {len(indice.documentos)} documentos de {codigos} códigos; "
          f"{'cargado desde caché' if en_cache else 'calculado y guardado'}")
    print("Consulta:", args.consulta)
    hallazgos = indice.buscar(args.consulta, modelo, top_k=args.top_k, umbral=args.umbral)
    if not hallazgos:
        print("No se encontraron candidatos por encima del umbral")
    for i, item in enumerate(hallazgos, 1):
        print(f"{i}. [{item['similitud']:.4f}] {item['codigo_candidato']} — "
              f"{item['descripcion_catalogo']}")
        print("   Texto similar:", item["texto_similar_catalogo"])
    print("AVISO: son similitudes semánticas, no probabilidades ni diagnósticos confirmados.")
    print("El índice inicial solo cubre códigos del léxico controlado, no el catálogo completo.")


if __name__ == "__main__":
    main()
