"""Validar códigos CIE-10 de notas ficticias contra el catálogo CodiEsp."""
import json
import csv
import sys
import os

# Forzar UTF-8 en stdout para Windows
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

os.chdir(os.path.dirname(os.path.abspath(__file__)))
project_root = os.path.join(os.path.dirname(__file__), "..")

# Cargar catálogo
catalog = {}
catalog_path = os.path.join(project_root, "data", "cie10", "cie10_catalog.csv")
with open(catalog_path, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        catalog[row["codigo"]] = row["descripcion_es"]

print(f"Catalogo cargado: {len(catalog)} codigos")

# Cargar notas
notes_path = os.path.join(project_root, "data", "clinical_notes", "sample_notes.json")
with open(notes_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# Validar cada código
print("\n=== Validacion de codigos contra catalogo ===")
issues = []
for nota in data["notas"]:
    nota_id = nota["id"]
    titulo = nota["titulo"]
    print(f"\n--- {nota_id}: {titulo} ---")
    for ce in nota["codigos_esperados"]:
        code = ce["codigo"]
        if code in catalog:
            desc = catalog[code][:70]
            print(f"  OK {code}: {desc}")
        else:
            # Buscar categoría
            cat_code = code.split(".")[0] if "." in code else code
            if cat_code in catalog:
                desc = catalog[cat_code][:70]
                print(f"  ~  {code}: exacto no encontrado, categoria {cat_code} si existe: {desc}")
                # Buscar subcódigos cercanos
                nearby = [k for k in catalog if k.startswith(code[:4])][:5]
                if nearby:
                    print(f"      Codigos cercanos: {nearby}")
                issues.append((nota_id, code, "categoria_existe"))
            else:
                print(f"  X  {code}: NO ENCONTRADO en catalogo")
                issues.append((nota_id, code, "no_encontrado"))

print(f"\n=== Resumen ===")
print(f"Notas: {len(data['notas'])}")
total_codes = sum(len(n['codigos_esperados']) for n in data['notas'])
print(f"Codigos totales: {total_codes}")
print(f"Issues: {len(issues)}")
for nota_id, code, issue_type in issues:
    print(f"  {nota_id} -> {code}: {issue_type}")
