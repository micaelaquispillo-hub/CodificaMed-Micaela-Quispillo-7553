"""Evaluación provisional de CodificaMed con proveedores REALES y notas ficticias.

Solo se consideran positivos los códigos esperados/predichos como 'confirmado'.
No utiliza las etiquetas de referencia para generar las predicciones. Los errores
no se cuentan como predicciones vacías ni como aciertos.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from src.evaluation.metricas import evaluar_caso, resumir_evaluaciones
from src.providers.configuracion import cargar_configuracion
from src.providers.pipeline import analizar_nota

DATOS = RAIZ / "data" / "clinical_notes" / "sample_notes.json"
SALIDA = RAIZ / "data" / "resultados"


def cargar_notas(ruta: Path = DATOS) -> list[dict]:
    with ruta.open(encoding="utf-8") as archivo:
        notas = json.load(archivo)["notas"]
    vistos = set()
    for nota in notas:
        if not isinstance(nota.get("id"), str) or nota["id"] in vistos:
            raise ValueError("Faltan identificadores de notas o están duplicados")
        vistos.add(nota["id"])
        if not isinstance(nota.get("texto"), str) or not nota["texto"].strip():
            raise ValueError(f"Texto ausente en {nota['id']}")
        if not isinstance(nota.get("codigos_esperados"), list):
            raise ValueError(f"Etiquetas ausentes en {nota['id']}")
        for etiqueta in nota["codigos_esperados"]:
            if not isinstance(etiqueta, dict) or not isinstance(etiqueta.get("codigo"), str):
                raise ValueError(f"Código de referencia inválido en {nota['id']}")
            if etiqueta.get("estado") not in {"confirmado", "negado", "descartado", "sospechado", "antecedente"}:
                raise ValueError(f"Estado de referencia inválido en {nota['id']}")
    return notas


def preparar_resumen(registros: list[dict], proveedores: list[str], ids: list[str]) -> dict:
    # Comparar solo las notas con ejecución correcta en TODOS los proveedores.
    completadas = {
        proveedor: {r["id_nota"] for r in registros if r["proveedor"] == proveedor and r["estado_ejecucion"] == "ok"}
        for proveedor in proveedores
    }
    comunes = set(ids)
    for proveedor in proveedores:
        comunes &= completadas[proveedor]
    resumen = {}
    for proveedor in proveedores:
        del_proveedor = [r for r in registros if r["proveedor"] == proveedor]
        validos = [r["evaluacion"] for r in del_proveedor if r["estado_ejecucion"] == "ok"]
        comparables = [r["evaluacion"] for r in del_proveedor if r["estado_ejecucion"] == "ok" and r["id_nota"] in comunes]
        latencias = [r["duracion_segundos"] for r in del_proveedor if r["estado_ejecucion"] == "ok"]
        resumen[proveedor] = {
            "ejecuciones_correctas": len(validos),
            "errores": len(del_proveedor) - len(validos),
            "evaluacion_disponible_no_comparable": resumir_evaluaciones(validos),
            "evaluacion_comparable": resumir_evaluaciones(comparables),
            "tiempo_promedio_segundos": round(sum(latencias) / len(latencias), 3) if latencias else None,
        }
    return {"notas_comunes": sorted(comunes), "resultados": resumen}


def guardar(registros: list[dict], reporte: dict, carpeta: Path) -> tuple[Path, Path]:
    carpeta.mkdir(parents=True, exist_ok=True)
    sello = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    ruta_json = carpeta / f"evaluacion_{sello}.json"
    ruta_csv = carpeta / f"evaluacion_{sello}.csv"
    with ruta_json.open("w", encoding="utf-8") as archivo:
        json.dump(reporte, archivo, ensure_ascii=False, indent=2)
    columnas = ["id_nota", "proveedor", "modelo", "estado_ejecucion", "tipo_error",
                "duracion_segundos", "vp", "fp", "fn", "precision", "recall", "f1",
                "codigos_esperados", "codigos_predichos", "rechazados"]
    with ruta_csv.open("w", encoding="utf-8-sig", newline="") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=columnas)
        escritor.writeheader()
        for r in registros:
            e = r.get("evaluacion") or {}
            escritor.writerow({
                "id_nota": r["id_nota"], "proveedor": r["proveedor"],
                "modelo": r["modelo"], "estado_ejecucion": r["estado_ejecucion"],
                "tipo_error": r.get("tipo_error", ""),
                "duracion_segundos": r.get("duracion_segundos"),
                "vp": e.get("vp"), "fp": e.get("fp"), "fn": e.get("fn"),
                "precision": e.get("precision"), "recall": e.get("recall"), "f1": e.get("f1"),
                "codigos_esperados": ",".join(e.get("codigos_esperados", [])),
                "codigos_predichos": ",".join(e.get("codigos_predichos", [])),
                "rechazados": r.get("rechazados", ""),
            })
    return ruta_json, ruta_csv


def main() -> None:
    p = argparse.ArgumentParser(description="Evaluación provisional con casos clínicos ficticios")
    p.add_argument("--proveedores", nargs="+", choices=["ollama", "gemini", "openai"],
                   default=["gemini", "ollama"])
    p.add_argument("--limite", type=int, default=1, help="Número de notas, 1 por defecto")
    p.add_argument("--desde", type=int, default=0, help="Índice inicial: 0 es nota_001")
    p.add_argument("--sin-embeddings", action="store_true")
    p.add_argument("--solo-preparar", action="store_true", help="Comprobar plan sin llamar a APIs")
    p.add_argument("--salida", type=Path, default=SALIDA)
    args = p.parse_args()

    proveedores = list(dict.fromkeys(args.proveedores))
    notas = cargar_notas()
    if args.desde < 0 or args.limite < 1 or args.desde >= len(notas):
        p.error("--desde o --limite inválido")
    seleccion = notas[args.desde:args.desde + args.limite]
    if not seleccion:
        p.error("No hay notas en el intervalo")
    configs = {prov: cargar_configuracion(prov) for prov in proveedores}
    print("AVISO: métricas PROVISIONALES; las etiquetas clínicas no están validadas definitivamente.")
    print("Los diagnósticos negativos/descartados NO cuentan como códigos confirmados.")
    print("Proveedores:", ", ".join(f"{n} ({configs[n].modelo})" for n in proveedores))
    print("Notas:", ", ".join(n["id"] for n in seleccion))
    print("Embeddings:", "NO" if args.sin_embeddings else "SÍ")
    print("Búsqueda TF-IDF catálogo:", "SÍ" if os.getenv("CODIFICAMED_TFIDF_CATALOGO") == "1" else "NO")
    print("Solicitudes máximas:", len(seleccion) * len(proveedores), "(podrían consumir cuota API)")
    if args.solo_preparar:
        print("Comprobación terminada: NO se consultaron modelos ni APIs.")
        return

    codificador = indice = None
    if not args.sin_embeddings:
        from src.retrieval.semantica import (
            MODELO_PREDETERMINADO, cargar_modelo, construir_o_cargar_indice,
        )
        codificador = cargar_modelo(MODELO_PREDETERMINADO)
        indice, cache = construir_o_cargar_indice(codificador, MODELO_PREDETERMINADO)
        print("Índice semántico:", "desde caché" if cache else "calculado")

    registros = []
    for nota in seleccion:
        for prov in proveedores:
            cfg = configs[prov]
            print(f"Procesando {nota['id']} con {prov} ({cfg.modelo})...")
            base = {"id_nota": nota["id"], "proveedor": prov, "modelo": cfg.modelo}
            try:
                salida = analizar_nota(nota["texto"], proveedor=prov,
                                       usar_embeddings=not args.sin_embeddings,
                                       codificador=codificador, indice=indice)
                met = evaluar_caso(nota["codigos_esperados"], salida["diagnosticos"])
                registro = {
                    **base, "estado_ejecucion": "ok",
                    "duracion_segundos": salida["duracion_segundos"],
                    "rechazados": len(salida.get("rechazados", [])),
                    "evaluacion": met,
                }
                print(f"  VP={met['vp']} FP={met['fp']} FN={met['fn']} F1={met['f1']}")
            except Exception as exc:
                # No volcar el cuerpo de la petición: puede incluir datos privados.
                registro = {**base, "estado_ejecucion": "error",
                            "tipo_error": type(exc).__name__, "evaluacion": None}
                print(f"  ERROR ({type(exc).__name__}). No se contará como predicción vacía.")
            registros.append(registro)

    resumen = preparar_resumen(registros, proveedores, [n["id"] for n in seleccion])
    reporte = {
        "caracter": "PROVISIONAL: referencias clínicas pendientes de revisión",
        "fecha_utc": datetime.now(timezone.utc).isoformat(),
        "version_conjunto": "sample_notes.json 1.0 (etiquetas en revisión)",
        "comparacion": "códigos confirmados exactos por nota, promedio micro",
        "embeddings": not args.sin_embeddings,
        "busqueda_tfidf_catalogo": os.getenv("CODIFICAMED_TFIDF_CATALOGO") == "1",
        "notas_seleccionadas": [n["id"] for n in seleccion],
        "resumen": resumen,
        "registros": registros,
    }
    rutas = guardar(registros, reporte, args.salida)
    print("Notas comunes con éxito:", len(resumen["notas_comunes"]))
    for prov, datos in resumen["resultados"].items():
        r = datos["evaluacion_comparable"]
        print(f"{prov}: VP={r['vp']} FP={r['fp']} FN={r['fn']} | P={r['precision']} R={r['recall']} F1={r['f1']}")
    print("Resultados guardados:", rutas[0], "y", rutas[1])
    if not resumen["notas_comunes"]:
        print("No hay notas comunes exitosas: NO realizar comparaciones de calidad.")
    print("No uses estas métricas en el informe final hasta revisar las etiquetas clínicas.")


if __name__ == "__main__":
    main()
