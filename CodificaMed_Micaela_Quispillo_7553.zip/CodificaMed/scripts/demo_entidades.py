"""Demuestra el reconocimiento de expresiones y candidatos con 10 notas ficticias."""
import json
import sys
from collections import Counter
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from src.nlp.entidades import detectar_entidades

with (RAIZ / "data" / "clinical_notes" / "sample_notes.json").open(encoding="utf-8") as f:
    notas = json.load(f)["notas"]

conteo = Counter()
for nota in notas:
    hallazgos = detectar_entidades(nota["texto"])
    conteo.update(item["estado_contextual"] for item in hallazgos)
    print(f"\n{nota['id']} - {len(hallazgos)} expresiones localizadas")
    for item in hallazgos:
        print(f"  [{item['estado_contextual']}] {item['expresion']} => {item['codigo_candidato']}")
        assert nota["texto"][item["inicio"]:item["fin"]] == item["expresion"]
        assert nota["texto"][item["inicio_evidencia"]:item["fin_evidencia"]] == item["evidencia"]
print("\nResultado del reconocimiento:", sum(conteo.values()), "expresiones; estados:", dict(conteo))
print("AVISO: códigos candidatos por diccionario. No hay embeddings ni inferencia LLM en este paso.")
