"""Ejecuta el preprocesamiento con las notas ficticias existentes."""
from pathlib import Path
import sys
import json

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
from src.nlp.preprocesamiento import procesar_nota

RUTA = RAIZ / "data" / "clinical_notes" / "sample_notes.json"
with RUTA.open(encoding="utf-8") as f:
    datos = json.load(f)

n_fragmentos = 0
n_marcadores = 0
for nota in datos["notas"]:
    resultado = procesar_nota(nota["texto"])
    n_fragmentos += len(resultado["fragmentos"])
    marcadores = [m for f in resultado["fragmentos"] for m in f["marcadores"]]
    n_marcadores += len(marcadores)
    assert all(nota["texto"][f["inicio"]:f["fin"]] == f["texto"] for f in resultado["fragmentos"])
    print(f'{nota["id"]}: {len(resultado["fragmentos"])} fragmentos, {len(marcadores)} marcadores')

print(f'Procesamiento completado: {len(datos["notas"])} notas, {n_fragmentos} fragmentos, {n_marcadores} marcadores')
print('IMPORTANTE: los marcadores son indicios; todavía no se asignan diagnósticos ni códigos.')
