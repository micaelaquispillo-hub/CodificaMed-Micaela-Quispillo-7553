"""Auditoria estructural de las notas ficticias; no valida la pertinencia clinica."""
from pathlib import Path
import csv
import json
import sys

RAIZ = Path(__file__).resolve().parent.parent
CAT = RAIZ / "data" / "cie10" / "cie10_catalog.csv"
NOTAS = RAIZ / "data" / "clinical_notes" / "sample_notes.json"

with CAT.open(encoding="utf-8", newline="") as archivo:
    catalogo = {fila["codigo"]: fila["descripcion_es"] for fila in csv.DictReader(archivo)}
with NOTAS.open(encoding="utf-8") as archivo:
    datos = json.load(archivo)

problemas = []
contadores = {"confirmado": 0, "negado": 0, "descartado": 0, "sospechado": 0, "antecedente": 0}
ids = set()
for nota in datos["notas"]:
    identificador = nota["id"]
    if identificador in ids:
        problemas.append((identificador, "ID duplicado"))
    ids.add(identificador)
    texto = nota.get("texto", "")
    if not isinstance(texto, str) or not texto.strip():
        problemas.append((identificador, "nota vacia"))
        continue
    codigos_vistos = set()
    for item in nota.get("codigos_esperados", []):
        codigo = item.get("codigo", "")
        estado = item.get("estado", "")
        evidencia = item.get("evidencia", "")
        if codigo not in catalogo:
            problemas.append((identificador, f"codigo inexistente: {codigo}"))
        elif item.get("descripcion_es") != catalogo[codigo]:
            problemas.append((identificador, f"descripcion no coincide: {codigo}"))
        if not isinstance(evidencia, str) or not evidencia or evidencia not in texto:
            problemas.append((identificador, f"evidencia no aparece literalmente: {codigo}"))
        if estado not in contadores:
            problemas.append((identificador, f"estado no reconocido: {estado}"))
        else:
            contadores[estado] += 1
        if codigo in codigos_vistos:
            problemas.append((identificador, f"codigo duplicado en nota: {codigo}"))
        codigos_vistos.add(codigo)

print(f"Catalogo: {len(catalogo)} codigos")
print(f"Notas: {len(datos['notas'])}")
print(f"Etiquetas: {sum(contadores.values())}")
print("Estados: " + ", ".join(f"{clave}={valor}" for clave, valor in contadores.items()))
print(f"Problemas estructurales: {len(problemas)}")
for identificador, error in problemas:
    print(f"- {identificador}: {error}")
print("AVISO: auditoria estructural; la revision de pertinencia clinica sigue pendiente.")
sys.exit(1 if problemas else 0)
