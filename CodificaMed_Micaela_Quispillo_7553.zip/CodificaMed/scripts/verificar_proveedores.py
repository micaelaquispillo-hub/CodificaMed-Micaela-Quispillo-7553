"""Verificaciones de Ollama y credenciales API sin hacer solicitudes de pago."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

import requests

from src.providers.configuracion import cargar_configuracion


def main():
    arg = argparse.ArgumentParser()
    arg.add_argument("--proveedor", choices=["ollama", "openai", "gemini"], required=True)
    nombre = arg.parse_args().proveedor
    cfg = cargar_configuracion(nombre)
    print(f"Proveedor: {cfg.nombre} | modelo configurado: {cfg.modelo}")
    if nombre in {"openai", "gemini"}:
        if cfg.clave:
            print("API key detectada (valor oculto). No se ha realizado ninguna solicitud.")
        else:
            variable = "GEMINI_API_KEY" if nombre == "gemini" else "OPENAI_API_KEY"
            print(f"Falta {variable}: configura .env, sin compartir la clave.")
            raise SystemExit(1)
    else:
        try:
            r = requests.get(f"{cfg.base_url}/api/tags", timeout=8)
            r.raise_for_status()
            disponibles = [m.get("name", "") for m in r.json().get("models", [])]
            print("Modelos locales:", ", ".join(disponibles) if disponibles else "ninguno")
            if cfg.modelo not in disponibles:
                print(f"Falta descargar el modelo. Ejecuta: ollama pull {cfg.modelo}")
                raise SystemExit(1)
            print("Ollama disponible, modelo instalado. La inferencia aún no se ha probado.")
        except requests.RequestException as exc:
            print("No se detectó el servidor de Ollama. Inicia Ollama y prueba 'ollama list'.")
            raise SystemExit(1) from None


if __name__ == "__main__":
    main()
