# CodificaMed (prototipo académico en desarrollo)

Tarea de la ESPOCH para codificación asistida CIE-10 de **notas ficticias** en español. Proyecto de aprendizaje; **no apto para uso clínico real**.

## Estado actual (paso 8)

- Catálogo CIE-10 y 10 notas ficticias con etiquetas iniciales. Las etiquetas deben revisarse antes de calcular métricas clínicas.
- Preprocesamiento, normalización de abreviaturas y extracción de marcadores de contexto.
- Reconocimiento léxico inicial de 28 conceptos clínicos y candidatos CIE-10.
- Índice semántico local con embeddings **sobre los 28 códigos del léxico**, no sobre los 98.288 del catálogo.
- Pruebas unitarias de los módulos (sin conexiones reales para comprobar la API).
- Integración de proveedores Ollama, OpenAI y Gemini, salida JSON estructurada y validación contra catálogo y evidencia literal.
- La ejecución real de embeddings en Windows ya fue verificada en el equipo del estudiante (paso 5).

**Verificado en Windows:** Ollama (`llama3.2:3b`) ejecutó una nota ficticia con embeddings y evidencia literal. **Verificado en Windows:** Gemini (`gemini-3.5-flash-lite`) también ejecutó la nota de prueba con embeddings. **Pendientes:** validar la interfaz en el navegador, ampliar y auditar los datos, las métricas independientes, el informe y la demostración.

## Instalación en PowerShell (Windows 11)

Abrir la carpeta `CodificaMed` en VS Code y comprobar:

```powershell
python --version
```

Si no tienes entorno virtual, crearlo e instalar dependencias:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Usar `python` en los ejemplos siguientes si ya estás trabajando en un entorno con las dependencias instaladas; también puedes sustituirlo por `.\.venv\Scripts\python.exe`.

## Pruebas

```powershell
python -m unittest discover -s tests -p "test_*.py" -v
python .\scripts\auditar_notas.py
python .\scripts\demo_preprocesamiento.py
python .\scripts\demo_entidades.py
```

## Embeddings reales

```powershell
python .\scripts\demo_semantica.py --consulta "Paciente con hipertensión arterial persistente"
```

La primera ejecución requiere acceso a Internet para descargar el modelo. Consulta `docs/paso5_embeddings.md` para el alcance, las limitaciones y la verificación de la caché.

## Proveedores de IA (pasos 6 y 7)

`config/settings.yaml` documenta parámetros; los proveedores activos se controlan con `.env` y `LLM_PROVIDER=ollama`, `LLM_PROVIDER=openai` o `LLM_PROVIDER=gemini`. **Ollama y Gemini ya fueron ejecutados con éxito en Windows usando notas ficticias.**

```powershell
Copy-Item .env.example .env
python .\scripts\verificar_proveedores.py --proveedor ollama
python .\scripts\demo_proveedores.py --proveedor ollama --sin-embeddings --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

Revisa `docs/paso6_proveedores.md` y `docs/paso7_gemini.md` para configuración, privacidad y pruebas del pipeline completo. No subas `.env` a GitHub.

## Privacidad y limitaciones

Solo notas ficticias. Los resultados devueltos por el diccionario o los embeddings son **candidatos de revisión**, no diagnósticos confirmados. La existencia de un código en el catálogo no valida su pertinencia clínica. Las diez notas del proyecto se usaron durante el desarrollo del léxico y no constituyen evaluación independiente.

## Gemini (proveedor externo con nivel gratuito limitado)

Para actualizar un proyecto existente sin duplicar la caché de embeddings, aplica el parche del paso 7 sobre la carpeta actual y mantén el vínculo `models_cache`. En `.env` configura `GEMINI_API_KEY`, `GEMINI_MODEL=gemini-3.5-flash-lite` y `LLM_PROVIDER=gemini`. No uses pacientes reales: las notas enviadas a la API salen de tu equipo y el nivel gratuito puede emplearlas para mejorar servicios.

```powershell
python .\scripts\verificar_proveedores.py --proveedor gemini
python .\scripts\demo_proveedores.py --proveedor gemini --sin-embeddings --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

Las pruebas automatizadas de Gemini usan respuestas simuladas. El funcionamiento real se comprobó por separado en el equipo del estudiante.


## Interfaz web (paso 8)

La interfaz Streamlit (`app.py`) integra el mismo pipeline usado por `scripts/demo_proveedores.py`, con selección de proveedor, recuperación semántica opcional y revisión manual de sugerencias. No se admite texto real de pacientes.

```powershell
python -m streamlit run app.py
```

Se abre normalmente `http://localhost:8501`. Revisa `docs/paso8_interfaz.md` para la instalación por parche, evidencias y limitaciones.

La interfaz aún no se ha probado en el navegador del estudiante; las pruebas automáticas comprueban las utilidades de presentación y el pipeline, no sustituyen esa comprobación real.
