"""Pruebas de infraestructura semántica con vectores SIMULADOS (sin IA real)."""
import tempfile
import unittest
from pathlib import Path

import numpy as np

from src.retrieval.semantica import (IndiceSemantico, _normalizar_matriz,
                                    construir_o_cargar_indice, preparar_documentos)


class CodificadorPrueba:
    """Vectores deterministas para probar ranking/caché, NO evaluación de embeddings."""
    def __init__(self):
        self.llamadas = 0

    def encode(self, textos, **kwargs):
        self.llamadas += 1
        salida = []
        for texto in textos:
            t = texto.casefold()
            if "hipertensi" in t or "arterial" in t or "presión" in t:
                salida.append([1.0, 0.0, 0.0])
            elif "diabetes" in t or "glucosa" in t:
                salida.append([0.0, 1.0, 0.0])
            else:
                salida.append([0.0, 0.0, 1.0])
        return np.array(salida, dtype=np.float32)


class PruebaRecuperacion(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ruta = Path(self.tmp.name) / "prueba.npz"
        self.modelo = CodificadorPrueba()

    def tearDown(self):
        self.tmp.cleanup()

    def test_documentos_usan_catalogo_y_lexico(self):
        documentos = preparar_documentos()
        self.assertGreater(len(documentos), 28)
        self.assertEqual(28, len({d["codigo"] for d in documentos}))

    def test_crea_indice_con_vectores_normalizados(self):
        indice, cache = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        self.assertFalse(cache)
        self.assertTrue(self.ruta.exists())
        np.testing.assert_allclose(np.linalg.norm(indice.vectores, axis=1), 1.0)

    def test_reutiliza_cache_sin_recalcular(self):
        construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        cuenta = self.modelo.llamadas
        _, cache = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        self.assertTrue(cache)
        self.assertEqual(cuenta, self.modelo.llamadas)

    def test_cambia_modelo_invalida_cache(self):
        construir_o_cargar_indice(self.modelo, "modelo1", self.ruta)
        _, cache = construir_o_cargar_indice(self.modelo, "modelo2", self.ruta)
        self.assertFalse(cache)

    def test_cache_corrupta_regenera(self):
        self.ruta.write_bytes(b"no es npz")
        _, cache = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        self.assertFalse(cache)

    def test_no_duplica_codigos(self):
        indice, _ = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        resultados = indice.buscar("presión arterial", self.modelo, top_k=8, umbral=0.9)
        codigos = [r["codigo_candidato"] for r in resultados]
        self.assertEqual(len(codigos), len(set(codigos)))
        self.assertIn("I10", codigos)
        self.assertTrue(all(r["estado"] == "requiere_revision" for r in resultados))

    def test_umbral_y_top_k(self):
        indice, _ = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        res = indice.buscar("glucosa", self.modelo, top_k=1, umbral=0.98)
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0]["codigo_candidato"], "E11")

    def test_consulta_vacia(self):
        indice, _ = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        with self.assertRaises(ValueError):
            indice.buscar("  ", self.modelo)

    def test_vectores_invalidos(self):
        with self.assertRaises(ValueError):
            _normalizar_matriz([[0.0, 0.0]], 1)
        with self.assertRaises(ValueError):
            _normalizar_matriz([[float("nan"), 1.0]], 1)
        with self.assertRaises(ValueError):
            _normalizar_matriz([[1, 2]], 2)

    def test_modelos_dimensiones_distintas(self):
        indice, _ = construir_o_cargar_indice(self.modelo, "simulado", self.ruta)
        class Otro:
            def encode(self, textos, **kwargs):
                return np.ones((len(textos), 4))
        with self.assertRaises(ValueError):
            indice.buscar("hipertensión", Otro())


if __name__ == "__main__":
    unittest.main()
