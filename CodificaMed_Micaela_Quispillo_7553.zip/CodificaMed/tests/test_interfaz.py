"""Pruebas de las utilidades de interfaz (sin invocar modelos ni red)."""
import csv
import io
import unittest

from src.ui_utilidades import exportar_csv_revision, preparar_revision, resumen_estados


class PruebaInterfaz(unittest.TestCase):
    def setUp(self):
        self.resultado = {
            "diagnosticos": [
                {"codigo": "I10", "descripcion": "Hipertensión esencial", "estado": "confirmado", "evidencia": "HTA"},
                {"codigo": "R50.9", "descripcion": "Fiebre", "estado": "negado", "evidencia": "Niega fiebre"},
                {"codigo": "J18.9", "descripcion": "Neumonía", "estado": "descartado", "evidencia": "Descarta neumonía"},
            ],
            "candidatos": [{"codigo": "I10"}, {"codigo": "R50.9"}],
            "rechazados": [{"codigo": "XXX", "motivo": "Desconocido"}],
        }

    def test_resumen_clasifica_confirmados_y_otros(self):
        self.assertEqual(resumen_estados(self.resultado), {
            "total": 3, "confirmados": 1, "otros_estados": 2,
            "rechazados": 1, "candidatos": 2,
        })

    def test_revisiones_nunca_se_marcan_automaticamente(self):
        filas = preparar_revision(self.resultado)
        self.assertEqual(len(filas), 3)
        self.assertTrue(all(fila["revisado"] is False for fila in filas))

    def test_estados_originales_no_se_modifican(self):
        filas = preparar_revision(self.resultado)
        self.assertEqual([x["estado"] for x in filas], ["confirmado", "negado", "descartado"])
        filas[0]["revisado"] = True
        self.assertNotIn("revisado", self.resultado["diagnosticos"][0])

    def test_csv_solo_revisados(self):
        filas = preparar_revision(self.resultado)
        filas[1]["revisado"] = True
        texto = exportar_csv_revision(filas).decode("utf-8-sig")
        datos = list(csv.DictReader(io.StringIO(texto), delimiter=";"))
        self.assertEqual(len(datos), 1)
        self.assertEqual(datos[0]["codigo"], "R50.9")
        self.assertEqual(datos[0]["estado"], "negado")
        self.assertEqual(datos[0]["revisado"], "si")

    def test_csv_todos_incluye_no_revisados(self):
        datos = list(csv.DictReader(
            io.StringIO(exportar_csv_revision(preparar_revision(self.resultado), False).decode("utf-8-sig")),
            delimiter=";"
        ))
        self.assertEqual(len(datos), 3)
        self.assertEqual(datos[0]["revisado"], "no")

    def test_csv_vacio_solo_encabezados(self):
        self.assertEqual(
            exportar_csv_revision([]).decode("utf-8-sig").strip(),
            "codigo;descripcion;estado;evidencia;revisado",
        )

    def test_csv_conserva_tildes_y_saltos(self):
        filas = preparar_revision(self.resultado)
        filas[0]["revisado"] = True
        filas[0]["evidencia"] = 'Se confirma "hipertensión"\narterial'
        contenido = exportar_csv_revision(filas).decode("utf-8-sig")
        self.assertIn('hipertensión', contenido)
        datos = list(csv.DictReader(io.StringIO(contenido), delimiter=";"))
        self.assertEqual(datos[0]["evidencia"], filas[0]["evidencia"])

    def test_resultado_vacio_es_valido(self):
        self.assertEqual(preparar_revision({"diagnosticos": []}), [])
        self.assertEqual(resumen_estados({}), {"total": 0, "confirmados": 0, "otros_estados": 0, "rechazados": 0, "candidatos": 0})

    def test_formato_invalido_rechazado(self):
        with self.assertRaises(ValueError):
            preparar_revision({"diagnosticos": "I10"})


if __name__ == "__main__":
    unittest.main()
