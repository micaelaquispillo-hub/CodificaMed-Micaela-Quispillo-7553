"""Pruebas del procesamiento; ejecutables con unittest o pytest."""
import unittest

from src.nlp.preprocesamiento import normalizar, expandir_abreviaturas, segmentar, procesar_nota
from src.nlp.contexto import detectar_marcadores


class PruebaPLN(unittest.TestCase):
    def test_normalizar_conserva_negacion_y_tildes(self):
        self.assertEqual(normalizar("  NIEGA   Fiebre  "), "niega fiebre")
        self.assertIn("hipertensión", normalizar("HIPERTENSIÓN"))

    def test_abreviaturas_sin_tocar_palabras(self):
        self.assertIn("hipertensión arterial", expandir_abreviaturas("Paciente con HTA"))
        self.assertIn("diabetes mellitus tipo 2", expandir_abreviaturas("DM2"))
        self.assertEqual(expandir_abreviaturas("metáfora"), "metáfora")

    def test_segmentacion_offsets_originales(self):
        nota = "  Niega fiebre.  Se descarta neumonía."
        trozos = segmentar(nota)
        self.assertEqual(len(trozos), 2)
        for t in trozos:
            self.assertEqual(nota[t["inicio"]:t["fin"]], t["texto"])

    def test_decimal_no_rompe_segmentacion(self):
        self.assertEqual(len(segmentar("Temperatura 38.2°C. Niega fiebre.")), 2)

    def test_marcadores_diferencian_descarte_y_negacion(self):
        texto = "Niega fiebre. Se descarta neumonía."
        self.assertEqual([m["tipo"] for m in detectar_marcadores(texto)],
                         ["negado", "descartado"])

    def test_contexto_mixto_no_asigna_estado_global(self):
        texto = "Se confirma apendicitis, pero se descarta obstrucción intestinal."
        resultado = procesar_nota(texto)
        tipos = {m["tipo"] for m in resultado["fragmentos"][0]["marcadores"]}
        self.assertEqual(tipos, {"confirmacion", "descartado"})

    def test_vacio_rechazado(self):
        with self.assertRaises(ValueError):
            procesar_nota(" \n ")

    def test_original_conservado(self):
        texto = "Paciente con HTA y DM2. Niega fiebre."
        salida = procesar_nota(texto)
        self.assertEqual(salida["texto_original"], texto)
        self.assertEqual(len(salida["fragmentos"]), 2)
        self.assertIn("hipertensión arterial", salida["fragmentos"][0]["texto_preparado"])


if __name__ == "__main__":
    unittest.main()
