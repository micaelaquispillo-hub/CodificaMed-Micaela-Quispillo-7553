"""Pruebas de la búsqueda TF-IDF independientes de proveedores y de las notas."""
import unittest
from unittest.mock import patch

from src.retrieval.busqueda_catalogo import _indice, buscar_en_catalogo


class TestBusquedaCatalogo(unittest.TestCase):
    def setUp(self):
        _indice.cache_clear()
        self.parche = patch("src.retrieval.busqueda_catalogo.cargar_catalogo", return_value={
            "K35.80": "Apendicitis aguda no especificada",
            "I10": "Hipertensión esencial (primaria)",
            "D25.1": "Leiomioma intramural de útero",
        })
        self.parche.start()

    def tearDown(self):
        self.parche.stop()
        _indice.cache_clear()

    def test_recupera_codigo_por_descripcion(self):
        r = buscar_en_catalogo([{"texto_preparado": "apendicitis aguda"}], umbral=0.05)
        self.assertEqual(r[0]["codigo"], "K35.80")

    def test_conserva_estructura_de_candidato(self):
        r = buscar_en_catalogo([{"texto": "leiomioma intramural de utero"}], umbral=0.05)
        self.assertEqual(r[0]["codigo"], "D25.1")
        self.assertIn("descripcion", r[0])
        self.assertEqual(r[0]["metodo"], "tfidf_catalogo")

    def test_entrada_vacia(self):
        self.assertEqual(buscar_en_catalogo([]), [])


if __name__ == "__main__":
    unittest.main()
