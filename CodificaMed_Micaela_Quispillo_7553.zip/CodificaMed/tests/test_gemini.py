"""Pruebas de integración aisladas: ninguna utiliza la API real ni consume cuota."""
from __future__ import annotations

import json
import os
import unittest
from unittest.mock import patch

import requests

from src.providers.configuracion import ConfigProveedor, cargar_configuracion, crear_proveedor
from src.providers.contrato import ESQUEMA
from src.providers.gemini_api import GeminiProveedor
from src.providers.pipeline import analizar_nota


class Respuesta:
    status_code = 200

    def __init__(self, texto=None, datos=None, finish_reason="STOP"):
        self.datos = datos if datos is not None else {
            "candidates": [{
                "content": {"parts": [{"text": texto if texto is not None else '{"diagnosticos":[]}'}]},
                "finishReason": finish_reason,
            }]
        }

    def raise_for_status(self):
        return None

    def json(self):
        return self.datos


class Sesion:
    def __init__(self, respuesta=None, error=None):
        self.respuesta = respuesta or Respuesta()
        self.error = error
        self.url = None
        self.headers = None
        self.cuerpo = None
        self.timeout = None

    def post(self, url, headers, json, timeout):
        self.url, self.headers, self.cuerpo, self.timeout = url, headers, json, timeout
        if self.error:
            raise self.error
        return self.respuesta


class PruebaGemini(unittest.TestCase):
    def setUp(self):
        self.cfg = ConfigProveedor("gemini", "gemini-2.5-flash", 30, clave="clave-no-real-prueba")
        self.nota = "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
        self.candidatos = [
            {"codigo": "I10", "descripcion": "Hipertensión esencial (primaria)"},
            {"codigo": "R50.9", "descripcion": "Fiebre"},
            {"codigo": "J18.9", "descripcion": "Neumonía"},
        ]

    def test_configuracion_por_env_y_fabrica(self):
        with patch.dict(os.environ, {"GEMINI_API_KEY": "clave-ficticia", "GEMINI_MODEL": "gemini-2.5-flash-lite", "LLM_PROVIDER": "gemini"}):
            cfg = cargar_configuracion()
            self.assertEqual(cfg.modelo, "gemini-2.5-flash-lite")
            self.assertEqual(cfg.nombre, "gemini")
            self.assertIsInstance(crear_proveedor(cfg), GeminiProveedor)

    def test_sin_clave_rechaza_antes_de_llamar(self):
        with self.assertRaisesRegex(ValueError, "GEMINI_API_KEY"):
            GeminiProveedor(ConfigProveedor("gemini", "gemini-2.5-flash", 30))

    def test_peticion_real_estructurada_y_sin_clave_en_url(self):
        sesion = Sesion()
        proveedor = GeminiProveedor(self.cfg, sesion)
        self.assertEqual(proveedor.analizar(self.nota, self.candidatos), {"diagnosticos": []})
        self.assertEqual(sesion.url, "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")
        self.assertNotIn(self.cfg.clave, sesion.url)
        self.assertEqual(sesion.headers["x-goog-api-key"], self.cfg.clave)
        self.assertEqual(sesion.cuerpo["generationConfig"]["responseMimeType"], "application/json")
        self.assertEqual(sesion.cuerpo["generationConfig"]["thinkingConfig"]["thinkingBudget"], 0)
        self.assertEqual(sesion.cuerpo["generationConfig"]["responseSchema"]["properties"]["diagnosticos"]["items"]["properties"], ESQUEMA["properties"]["diagnosticos"]["items"]["properties"])
        self.assertIn("NOTA_ORIGINAL", sesion.cuerpo["contents"][0]["parts"][0]["text"])

    def test_parsea_diagnostico_json(self):
        esperado = {"diagnosticos": [{"codigo": "I10", "estado": "confirmado", "evidencia": "Se confirma hipertensión arterial esencial."}]}
        sesion = Sesion(respuesta=Respuesta(json.dumps(esperado, ensure_ascii=False)))
        self.assertEqual(GeminiProveedor(self.cfg, sesion).analizar(self.nota, self.candidatos), esperado)

    def test_validador_comun_rechaza_negado_como_confirmado(self):
        falso = {"diagnosticos": [{"codigo": "R50.9", "estado": "confirmado", "evidencia": "Niega fiebre"}]}
        sesion = Sesion(respuesta=Respuesta(json.dumps(falso)))
        resultado = analizar_nota(self.nota, proveedor="gemini", usar_embeddings=False, proveedor_obj=GeminiProveedor(self.cfg, sesion))
        self.assertEqual(resultado["confirmados"], [])
        self.assertEqual(len(resultado["rechazados"]), 1)
        self.assertEqual(resultado["proveedor"], "gemini")

    def test_respuesta_json_invalida(self):
        p = GeminiProveedor(self.cfg, Sesion(respuesta=Respuesta('{"diagnosticos": [}')))
        with self.assertRaisesRegex(ValueError, "JSON inválida"):
            p.analizar(self.nota, self.candidatos)

    def test_respuesta_sin_candidatos(self):
        p = GeminiProveedor(self.cfg, Sesion(respuesta=Respuesta(datos={"candidates": []})))
        with self.assertRaisesRegex(ValueError, "no generó"):
            p.analizar(self.nota, self.candidatos)

    def test_respuesta_interrumpida(self):
        p = GeminiProveedor(self.cfg, Sesion(respuesta=Respuesta(finish_reason="MAX_TOKENS")))
        with self.assertRaisesRegex(ValueError, "interrumpió"):
            p.analizar(self.nota, self.candidatos)

    def test_http429_sin_fuga_clave(self):
        error = requests.HTTPError("https://url-con-secret?key=clave-no-real-prueba")
        respuesta = Respuesta()
        respuesta.status_code = 429
        error.response = respuesta
        p = GeminiProveedor(self.cfg, Sesion(respuesta=respuesta, error=error))
        with self.assertRaises(RuntimeError) as cm:
            p.analizar(self.nota, self.candidatos)
        self.assertIn("429", str(cm.exception))
        self.assertNotIn(self.cfg.clave, str(cm.exception))

    def test_timeout_sin_fuga(self):
        p = GeminiProveedor(self.cfg, Sesion(error=requests.Timeout("clave-no-real-prueba")))
        with self.assertRaisesRegex(RuntimeError, "tiempo de espera"):
            p.analizar(self.nota, self.candidatos)

    def test_modelo_no_permitido(self):
        cfg = ConfigProveedor("gemini", "../../otro", 30, clave="ficticia")
        p = GeminiProveedor(cfg, Sesion())
        with self.assertRaisesRegex(ValueError, "modelo válido"):
            p.analizar(self.nota, self.candidatos)

    def test_no_inferencia_si_no_hay_candidatos(self):
        sesion = Sesion()
        r = analizar_nota("Una nota sin ninguna entidad clínica relevante.", proveedor="gemini", usar_embeddings=False, proveedor_obj=GeminiProveedor(self.cfg, sesion))
        self.assertEqual(r["diagnosticos"], [])
        self.assertIsNone(sesion.url)


if __name__ == "__main__":
    unittest.main()
