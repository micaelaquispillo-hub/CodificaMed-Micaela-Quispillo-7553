"""Pruebas unitarias del vocabulario clínico y estados por mención."""
import unittest

from src.nlp.entidades import detectar_entidades, cargar_lexico
from src.retrieval.catalogo import cargar_catalogo


class PruebaEntidades(unittest.TestCase):
    def test_ejemplo_basico_estados_independientes(self):
        texto = "Paciente con HTA y DM2. Niega fiebre. Se descarta neumonía."
        items = detectar_entidades(texto)
        self.assertEqual([(x["expresion"], x["estado_contextual"]) for x in items], [
            ("HTA", "sin_contexto"), ("DM2", "sin_contexto"),
            ("fiebre", "negado"), ("neumonía", "descartado")
        ])

    def test_confirmacion_explicita(self):
        items = detectar_entidades("Ecografía confirma apendicitis.")
        self.assertEqual(items[0]["estado_contextual"], "confirmado")

    def test_sospecha_no_confirmada(self):
        items = detectar_entidades("Se sospecha apendicitis aguda.")
        self.assertEqual(items[0]["estado_contextual"], "sospechado")

    def test_marcadores_en_misma_oracion(self):
        items = detectar_entidades("Se confirma apendicitis, pero se descarta obstrucción intestinal.")
        self.assertEqual([(x["codigo_candidato"], x["estado_contextual"]) for x in items],
                         [("K35", "confirmado"), ("K56", "descartado")])

    def test_variantes_de_abreviatura(self):
        items = detectar_entidades("HTA y DM2 diagnosticadas.")
        self.assertEqual([x["codigo_candidato"] for x in items], ["I10", "E11"])

    def test_no_buscar_dentro_de_otra_palabra(self):
        self.assertEqual(detectar_entidades("Una metáfora y neumoniamente."), [])

    def test_sufijo_descartado(self):
        items = detectar_entidades("Neumonía descartada.")
        self.assertEqual(items[0]["estado_contextual"], "descartado")

    def test_no_se_descarta_es_ambiguo(self):
        items = detectar_entidades("No se descarta neumonía.")
        self.assertEqual(items[0]["estado_contextual"], "revisar")

    def test_negacion_no_se_propaga_tras_pero(self):
        items = detectar_entidades("Niega fiebre, pero presenta hipertensión.")
        self.assertEqual([x["estado_contextual"] for x in items], ["negado", "sin_contexto"])

    def test_no_inventa_entradas_fuera_lexico(self):
        self.assertEqual(detectar_entidades("Paciente con una enfermedad rara sin nombre."), [])

    def test_evidencia_y_offsets(self):
        texto = "  HTA y DM2.  Niega fiebre."
        for item in detectar_entidades(texto):
            self.assertEqual(item["expresion"], texto[item["inicio"]:item["fin"]])
            self.assertEqual(item["evidencia"], texto[item["inicio_evidencia"]:item["fin_evidencia"]])

    def test_codigos_existentes(self):
        catalogo = cargar_catalogo()
        self.assertTrue(all(x["codigo"] in catalogo for x in cargar_lexico()))

    def test_texto_vacio_rechazado(self):
        with self.assertRaises(ValueError):
            detectar_entidades("  ")


if __name__ == "__main__":
    unittest.main()
