"""Pruebas sin conexión externa: no simulan haber ejecutado modelos reales."""
from __future__ import annotations

import json
import os
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from src.providers.configuracion import ConfigProveedor, cargar_configuracion
from src.providers.ollama_local import OllamaProveedor
from src.providers.openai_api import OpenAIProveedor
from src.providers.pipeline import analizar_nota, recuperar_candidatos
from src.providers.validacion import validar_respuesta
from src.providers.contrato import ESQUEMA


class RespuestaHTTP:
    def __init__(self, contenido):
        self.contenido = contenido

    def raise_for_status(self):
        return None

    def json(self):
        return {"message": {"content": self.contenido}}


class SesionHTTP:
    def __init__(self, contenido):
        self.contenido = contenido
        self.url = None
        self.payload = None

    def post(self, url, json, timeout):
        self.url = url
        self.payload = json
        return RespuestaHTTP(self.contenido)


class FakeResponses:
    def __init__(self, contenido):
        self.contenido = contenido
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        return SimpleNamespace(output_text=self.contenido)


class FakeProveedor:
    def __init__(self, contenido):
        self.contenido = contenido
        self.candidatos = None

    def analizar(self, texto, candidatos):
        self.candidatos = candidatos
        return self.contenido


class PruebaProveedores(unittest.TestCase):
    def setUp(self):
        self.nota = "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
        self.candidatos = [
            {"codigo": "I10", "descripcion": "Hipertensión esencial (primaria)"},
            {"codigo": "R50.9", "descripcion": "Fiebre"},
            {"codigo": "J18.9", "descripcion": "Neumonía"},
        ]

    def test_salida_compartida(self):
        self.assertEqual(ESQUEMA["required"], ["diagnosticos"])
        self.assertFalse(ESQUEMA["additionalProperties"])

    def test_ollama_hace_post_real_a_ruta_esperada_con_formato_estructurado(self):
        sesion = SesionHTTP(json.dumps({"diagnosticos": []}))
        proveedor = OllamaProveedor(ConfigProveedor("ollama", "qwen2.5:3b", 20, "http://localhost:11434"), sesion)
        self.assertEqual(proveedor.analizar(self.nota, self.candidatos), {"diagnosticos": []})
        self.assertEqual(sesion.url, "http://localhost:11434/api/chat")
        self.assertFalse(sesion.payload["stream"])
        self.assertEqual(sesion.payload["format"], ESQUEMA)
        self.assertIn("NOTA_ORIGINAL:", sesion.payload["messages"][1]["content"])

    def test_ollama_json_invalido(self):
        proveedor = OllamaProveedor(ConfigProveedor("ollama", "qwen2.5:3b", 20, "http://localhost:11434"), SesionHTTP("NO JSON"))
        with self.assertRaises(ValueError):
            proveedor.analizar(self.nota, self.candidatos)

    def test_openai_sin_credenciales(self):
        with self.assertRaisesRegex(ValueError, "OPENAI_API_KEY"):
            OpenAIProveedor(ConfigProveedor("openai", "gpt-4o-mini", 20))

    def test_openai_configura_schema_y_no_guarda_resultados(self):
        resp = FakeResponses('{"diagnosticos":[]}')
        p = OpenAIProveedor(ConfigProveedor("openai", "gpt-4o-mini", 20), SimpleNamespace(responses=resp))
        self.assertEqual(p.analizar(self.nota, self.candidatos), {"diagnosticos": []})
        self.assertEqual(resp.kwargs["text"]["format"]["schema"], ESQUEMA)
        self.assertEqual(resp.kwargs["model"], "gpt-4o-mini")
        self.assertIs(resp.kwargs["store"], False)

    def test_openai_json_truncado(self):
        resp = FakeResponses('{"diagnosticos":[')
        p = OpenAIProveedor(ConfigProveedor("openai", "gpt-4o-mini", 20), SimpleNamespace(responses=resp))
        with self.assertRaises(ValueError):
            p.analizar(self.nota, self.candidatos)

    def test_evidencia_literal_y_codigo_permitido(self):
        raw = {"diagnosticos": [{"codigo": "I10", "estado": "confirmado", "evidencia": "Se confirma hipertensión arterial esencial"}]}
        validado = validar_respuesta(raw, self.nota, self.candidatos)
        self.assertEqual(len(validado["confirmados"]), 1)
        self.assertEqual(validado["confirmados"][0]["codigo"], "I10")

    def test_modelo_no_puede_confirmar_diagnostico_negado(self):
        raw = {"diagnosticos": [{"codigo": "R50.9", "estado": "confirmado", "evidencia": "Niega fiebre"}]}
        validado = validar_respuesta(raw, self.nota, self.candidatos)
        self.assertEqual(validado["confirmados"], [])
        self.assertIn("Contradice", validado["rechazados"][0]["motivo"])

    def test_modelo_no_puede_confirmar_diagnostico_descartado(self):
        raw = {"diagnosticos": [{"codigo": "J18.9", "estado": "confirmado", "evidencia": "Se descarta neumonía"}]}
        validado = validar_respuesta(raw, self.nota, self.candidatos)
        self.assertEqual(validado["confirmados"], [])
        self.assertEqual(len(validado["rechazados"]), 1)

    def test_evidencia_inexistente_rechazada(self):
        raw = {"diagnosticos": [{"codigo": "I10", "estado": "confirmado", "evidencia": "Hipertensión severa diagnosticada hoy"}]}
        self.assertEqual(len(validar_respuesta(raw, self.nota, self.candidatos)["rechazados"]), 1)

    def test_codigo_no_en_candidatos_rechazado(self):
        raw = {"diagnosticos": [{"codigo": "E11", "estado": "confirmado", "evidencia": "hipertensión arterial esencial"}]}
        self.assertEqual(len(validar_respuesta(raw, self.nota, self.candidatos)["rechazados"]), 1)

    def test_codigo_fuera_de_catalogo_rechazado(self):
        raw = {"diagnosticos": [{"codigo": "XYZ999", "estado": "confirmado", "evidencia": "hipertensión arterial esencial"}]}
        self.assertEqual(len(validar_respuesta(raw, self.nota, self.candidatos)["rechazados"]), 1)

    def test_duplicados_se_descartan(self):
        item = {"codigo": "I10", "estado": "confirmado", "evidencia": "Se confirma hipertensión arterial esencial"}
        resultado = validar_respuesta({"diagnosticos": [item, item]}, self.nota, self.candidatos)
        self.assertEqual(len(resultado["confirmados"]), 1)
        self.assertEqual(len(resultado["rechazados"]), 1)

    def test_no_se_acepta_json_sin_diagnosticos(self):
        with self.assertRaises(ValueError):
            validar_respuesta({}, self.nota, self.candidatos)

    def test_candidatos_sin_embeddings(self):
        r = recuperar_candidatos(self.nota, usar_embeddings=False)
        self.assertIn("I10", {x["codigo"] for x in r})
        self.assertIn("J18.9", {x["codigo"] for x in r})

    def test_pipeline_funciona_con_proveedor_inyectado(self):
        falso = FakeProveedor({"diagnosticos": [{"codigo": "I10", "estado": "confirmado", "evidencia": "Se confirma hipertensión arterial esencial"}]})
        resultado = analizar_nota(self.nota, proveedor="ollama", usar_embeddings=False, proveedor_obj=falso)
        self.assertEqual(resultado["proveedor"], "ollama")
        self.assertEqual(len(resultado["confirmados"]), 1)
        self.assertTrue(falso.candidatos)

    def test_cambio_de_proveedor_por_configuracion(self):
        with patch.dict(os.environ, {"LLM_PROVIDER": "openai", "OPENAI_MODEL": "gpt-4o-mini"}):
            cfg = cargar_configuracion()
            self.assertEqual(cfg.nombre, "openai")
        with patch.dict(os.environ, {"LLM_PROVIDER": "ollama", "OLLAMA_MODEL": "qwen2.5:3b"}):
            cfg = cargar_configuracion()
            self.assertEqual(cfg.nombre, "ollama")

    def test_proveedor_desconocido_no_es_simulado(self):
        with self.assertRaises(ValueError):
            cargar_configuracion("proveedor_inexistente")

    def test_nota_vacia_rechazada_antes_de_llm(self):
        with self.assertRaises(ValueError):
            analizar_nota("  ", usar_embeddings=False)

    def test_no_se_hace_inferencia_si_no_hay_candidatos(self):
        falso = FakeProveedor({"diagnosticos": []})
        resultado = analizar_nota("No hay términos clínicos conocidos.", proveedor="ollama", usar_embeddings=False, proveedor_obj=falso)
        self.assertEqual(resultado["diagnosticos"], [])
        self.assertIsNone(falso.candidatos)


if __name__ == "__main__":
    unittest.main()
