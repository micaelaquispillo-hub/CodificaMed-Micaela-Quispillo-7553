"""Verificación reproducible de las métricas; no realiza llamadas a IA."""
import unittest

from src.evaluation.metricas import (
    evaluar_caso, metricas_conteos, resumir_evaluaciones,
)


def d(c, e="confirmado"):
    return {"codigo": c, "estado": e}


class PruebaEvaluacion(unittest.TestCase):
    def test_coincidencia_perfecta(self):
        r = evaluar_caso([d("I10")], [d("I10")])
        self.assertEqual((r["vp"], r["fp"], r["fn"]), (1, 0, 0))
        self.assertEqual(r["f1"], 1.0)

    def test_omision(self):
        r = evaluar_caso([d("I10"), d("E11")], [d("I10")])
        self.assertEqual((r["vp"], r["fp"], r["fn"]), (1, 0, 1))
        self.assertAlmostEqual(r["recall"], .5)
        self.assertAlmostEqual(r["f1"], 2 / 3)

    def test_codigo_falso(self):
        r = evaluar_caso([d("I10")], [d("I10"), d("E11")])
        self.assertEqual((r["vp"], r["fp"], r["fn"]), (1, 1, 0))
        self.assertAlmostEqual(r["precision"], .5)

    def test_negado_predicho_confirmado_es_falso_positivo(self):
        r = evaluar_caso([d("R50.9", "negado")], [d("R50.9", "confirmado")])
        self.assertEqual((r["vp"], r["fp"], r["fn"]), (0, 1, 0))

    def test_negados_no_son_positivos(self):
        r = evaluar_caso([d("I10"), d("R50.9", "negado")],
                         [d("I10"), d("R50.9", "negado")])
        self.assertEqual((r["vp"], r["fp"], r["fn"]), (1, 0, 0))

    def test_caso_sin_positivos_no_fabrica_puntaje(self):
        r = evaluar_caso([d("R50.9", "descartado")], [])
        self.assertIsNone(r["precision"])
        self.assertIsNone(r["recall"])
        self.assertIsNone(r["f1"])

    def test_agregacion_micro(self):
        a = evaluar_caso([d("I10"), d("E11")], [d("I10")])
        b = evaluar_caso([d("J18.9")], [d("J18.9"), d("E78.0")])
        r = resumir_evaluaciones([a, b])
        self.assertEqual((r["vp"], r["fp"], r["fn"]), (2, 1, 1))
        self.assertAlmostEqual(r["f1"], 2/3)

    def test_entradas_incorrectas(self):
        with self.assertRaises(ValueError):
            evaluar_caso("I10", [])
        with self.assertRaises(ValueError):
            evaluar_caso([{}], [])
        with self.assertRaises(ValueError):
            metricas_conteos(-1, 0, 0)


if __name__ == "__main__":
    unittest.main()
