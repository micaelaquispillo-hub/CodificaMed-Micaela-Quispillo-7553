"""Métricas por coincidencia exacta de códigos CONFIRMADOS.

La referencia puede contener etiquetas negadas, descartadas, sospechadas o de
antecedentes: no se cuentan como positivos, y una predicción confirmada de
esos códigos se cuenta como falso positivo.
"""
from __future__ import annotations


def codigos_confirmados(items: list[dict]) -> set[str]:
    if not isinstance(items, list):
        raise ValueError("Las etiquetas o predicciones deben ser una lista")
    codigos: set[str] = set()
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("codigo"), str):
            raise ValueError("Etiqueta inválida: falta código")
        if item.get("estado") == "confirmado":
            codigos.add(item["codigo"].strip().upper())
    return codigos


def metricas_conteos(vp: int, fp: int, fn: int) -> dict:
    if min(vp, fp, fn) < 0:
        raise ValueError("Los conteos no pueden ser negativos")
    return {
        "precision": vp / (vp + fp) if vp + fp else None,
        "recall": vp / (vp + fn) if vp + fn else None,
        "f1": 2 * vp / (2 * vp + fp + fn) if 2 * vp + fp + fn else None,
    }


def evaluar_caso(esperados: list[dict], predichos: list[dict]) -> dict:
    ref = codigos_confirmados(esperados)
    pred = codigos_confirmados(predichos)
    correctos = ref & pred
    extras = pred - ref
    omitidos = ref - pred
    vp, fp, fn = len(correctos), len(extras), len(omitidos)
    return {
        "vp": vp, "fp": fp, "fn": fn,
        "codigos_esperados": sorted(ref),
        "codigos_predichos": sorted(pred),
        "aciertos": sorted(correctos),
        "extras": sorted(extras),
        "omitidos": sorted(omitidos),
        **metricas_conteos(vp, fp, fn),
    }


def resumir_evaluaciones(evaluaciones: list[dict]) -> dict:
    vp = sum(r["vp"] for r in evaluaciones)
    fp = sum(r["fp"] for r in evaluaciones)
    fn = sum(r["fn"] for r in evaluaciones)
    return {
        "notas_evaluadas": len(evaluaciones),
        "vp": vp, "fp": fp, "fn": fn,
        **metricas_conteos(vp, fp, fn),
    }
