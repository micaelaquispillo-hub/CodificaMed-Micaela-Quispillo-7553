"""Recuperación semántica sobre un vocabulario clínico CONTROLADO.

Un resultado es un candidato, NO un diagnóstico confirmado. No lee las etiquetas
'codigos_esperados' del corpus. El catálogo completo contiene muchos más códigos
que el subconjunto utilizado por este índice académico inicial.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from src.nlp.entidades import RUTA_LEXICO
from src.retrieval.catalogo import RAIZ, cargar_catalogo

MODELO_PREDETERMINADO = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
RUTA_INDICE = RAIZ / "data" / "cie10" / "indice_lexico_embeddings.npz"


def preparar_documentos() -> list[dict[str, str]]:
    """Crea documentos de búsqueda sin utilizar las etiquetas de las notas.

    Cada sinónimo y cada descripción sirve como documento independiente; el
    ranking final conserva solamente la mejor puntuación de cada código.
    """
    with RUTA_LEXICO.open(encoding="utf-8") as archivo:
        datos = json.load(archivo)
    catalogo = cargar_catalogo()
    documentos: list[dict[str, str]] = []
    vistos: set[tuple[str, str]] = set()
    for entrada in datos["entradas"]:
        codigo = entrada["codigo"]
        if codigo not in catalogo:
            raise ValueError(f"Código no encontrado en catálogo: {codigo}")
        textos = [entrada["concepto"], catalogo[codigo], *entrada["sinonimos"]]
        for texto in textos:
            texto = texto.strip()
            clave = codigo, texto.casefold()
            if texto and clave not in vistos:
                vistos.add(clave)
                documentos.append({"codigo": codigo, "texto": texto})
    if not documentos:
        raise ValueError("El léxico no tiene documentos válidos")
    return documentos


def _firma(documentos: list[dict[str, str]], nombre_modelo: str) -> str:
    datos = json.dumps({"modelo": nombre_modelo, "documentos": documentos},
                       ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(datos).hexdigest()


def _normalizar_matriz(valores: Any, filas: int) -> np.ndarray:
    matriz = np.asarray(valores, dtype=np.float32)
    if matriz.ndim != 2 or matriz.shape[0] != filas or matriz.shape[1] == 0:
        raise ValueError(f"Embeddings con forma incorrecta: {matriz.shape}")
    if not np.isfinite(matriz).all():
        raise ValueError("Los embeddings contienen valores no finitos")
    normas = np.linalg.norm(matriz, axis=1, keepdims=True)
    if np.any(normas <= 0):
        raise ValueError("Existe un vector de embedding vacío")
    return matriz / normas


def cargar_modelo(nombre_modelo: str = MODELO_PREDETERMINADO):
    """Carga el modelo real bajo demanda; requiere instalación y primera descarga."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError(
            "Falta sentence-transformers. Instala: python -m pip install -r requirements.txt"
        ) from exc
    try:
        return SentenceTransformer(nombre_modelo, cache_folder=str(RAIZ / "models_cache"))
    except Exception as exc:
        raise RuntimeError(
            "No se pudo cargar el modelo de embeddings. Verifica la conexión para "
            "la primera descarga, la memoria disponible y el nombre del modelo."
        ) from exc


@dataclass
class IndiceSemantico:
    documentos: list[dict[str, str]]
    vectores: np.ndarray
    modelo: str
    firma: str

    def buscar(self, consulta: str, codificador: Any, top_k: int = 5,
               umbral: float = 0.35) -> list[dict[str, Any]]:
        """Devuelve candidatos distintos ordenados por coseno, para revisión."""
        if not isinstance(consulta, str) or not consulta.strip():
            raise ValueError("La consulta clínica no puede estar vacía")
        if not isinstance(top_k, int) or not 1 <= top_k <= 100:
            raise ValueError("top_k debe estar entre 1 y 100")
        if not -1.0 <= umbral <= 1.0:
            raise ValueError("El umbral debe estar entre -1 y 1")
        vector = _normalizar_matriz(
            codificador.encode([consulta], convert_to_numpy=True,
                               show_progress_bar=False), 1
        )[0]
        if vector.shape[0] != self.vectores.shape[1]:
            raise ValueError("Dimensión incompatible entre el índice y el modelo")
        puntuaciones = self.vectores @ vector
        mejores: dict[str, dict[str, Any]] = {}
        catalogo = cargar_catalogo()
        for doc, similitud in zip(self.documentos, puntuaciones):
            valor = float(similitud)
            if valor < umbral:
                continue
            codigo = doc["codigo"]
            if codigo not in mejores or valor > mejores[codigo]["similitud"]:
                mejores[codigo] = {
                    "codigo_candidato": codigo,
                    "descripcion_catalogo": catalogo[codigo],
                    "texto_similar_catalogo": doc["texto"],
                    "similitud": round(valor, 4),
                    "metodo": "embeddings_coseno",
                    "estado": "requiere_revision",
                }
        return sorted(mejores.values(),
                      key=lambda x: (-x["similitud"], x["codigo_candidato"]))[:top_k]


def construir_o_cargar_indice(codificador: Any, nombre_modelo: str,
                              ruta: Path = RUTA_INDICE) -> tuple[IndiceSemantico, bool]:
    """Calcula embeddings y los guarda; reutiliza caché solo con firma coincidente.

    Retorna (índice, usado_cache). En las pruebas se inyecta un codificador falso
    para probar la lógica SIN presentar ese codificador como un modelo entrenado.
    """
    documentos = preparar_documentos()
    firma = _firma(documentos, nombre_modelo)
    ruta = Path(ruta)
    if ruta.exists():
        try:
            with np.load(ruta, allow_pickle=False) as datos:
                if str(datos["firma"].item()) == firma:
                    matriz = _normalizar_matriz(datos["vectores"], len(documentos))
                    return IndiceSemantico(documentos, matriz, nombre_modelo, firma), True
        except (OSError, ValueError, KeyError, EOFError):
            pass  # Se regenerará el índice si está corrupto o es incompatible.
    textos = [item["texto"] for item in documentos]
    vectores = _normalizar_matriz(
        codificador.encode(textos, batch_size=32, convert_to_numpy=True,
                           show_progress_bar=False), len(documentos)
    )
    ruta.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(ruta, vectores=vectores, firma=np.array(firma))
    return IndiceSemantico(documentos, vectores, nombre_modelo, firma), False
