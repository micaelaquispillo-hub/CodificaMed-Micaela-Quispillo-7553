"""Módulos de recuperación semántica."""

