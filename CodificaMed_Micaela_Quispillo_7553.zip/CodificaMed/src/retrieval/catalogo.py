"""Consulta local del catálogo CIE-10 usado por el prototipo."""
from __future__ import annotations

import csv
from functools import lru_cache
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
RUTA_CATALOGO = RAIZ / "data" / "cie10" / "cie10_catalog.csv"


@lru_cache(maxsize=1)
def cargar_catalogo() -> dict[str, str]:
    """Carga el catálogo, conservando exactamente sus códigos y descripciones."""
    with RUTA_CATALOGO.open(encoding="utf-8", newline="") as archivo:
        return {fila["codigo"]: fila["descripcion_es"] for fila in csv.DictReader(archivo)}


def descripcion_codigo(codigo: str) -> str | None:
    return cargar_catalogo().get(codigo)
