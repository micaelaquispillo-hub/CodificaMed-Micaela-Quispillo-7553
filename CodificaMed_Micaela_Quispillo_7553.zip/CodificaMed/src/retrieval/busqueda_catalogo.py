"""Búsqueda TF-IDF sobre descripciones de todo el catálogo, sin etiquetas de evaluación.

No certifica diagnósticos: ofrece candidatos para selección y validación posterior.
La matriz se crea en memoria una sola vez por proceso; no se descarga nada.
"""
from __future__ import annotations

from functools import lru_cache

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from src.retrieval.catalogo import cargar_catalogo

_STOP = [
    "de", "del", "la", "el", "los", "las", "un", "una", "unos", "unas",
    "en", "por", "para", "con", "al", "y", "o", "su", "sus", "se", "que",
    "como", "tipo", "otro", "otros", "otra", "otras", "no", "especificado",
    "especificada", "especificados", "especificadas", "parte", "sin", "debido",
]


@lru_cache(maxsize=1)
def _indice():
    catalogo = cargar_catalogo()
    codigos = tuple(catalogo)
    descripciones = tuple(catalogo.values())
    vectorizador = TfidfVectorizer(
        lowercase=True,
        strip_accents="unicode",
        ngram_range=(1, 2),
        stop_words=_STOP,
        min_df=1,
        max_features=60000,
        sublinear_tf=True,
        dtype=np.float32,
    )
    matriz = vectorizador.fit_transform(descripciones)
    return codigos, descripciones, vectorizador, matriz


def buscar_en_catalogo(fragmentos: list[dict], top_k: int = 75, por_fragmento: int = 7,
                       umbral: float = 0.12) -> list[dict]:
    """Recupera códigos ordenados por similitud máxima entre fragmentos y descripciones.

    No abre archivos de notas etiquetadas ni consulta etiquetas esperadas.
    """
    textos = [frag.get("texto_preparado") or frag.get("texto", "") for frag in fragmentos]
    textos = [t for t in textos if isinstance(t, str) and t.strip()]
    if not textos or top_k < 1:
        return []
    codigos, descripciones, vectorizador, matriz = _indice()
    consultas = vectorizador.transform(textos)
    puntuaciones = matriz @ consultas.T
    mejores = {}
    # Cada fragmento contribuye candidatos para evitar que una sola oración
    # monopolice los resultados.
    for columna in range(puntuaciones.shape[1]):
        valores = puntuaciones.getcol(columna).toarray().ravel()
        indices = np.flatnonzero(valores >= umbral)
        if not indices.size:
            continue
        cantidad = min(por_fragmento, indices.size)
        if indices.size > cantidad:
            indices = indices[np.argpartition(valores[indices], -cantidad)[-cantidad:]]
        indices = sorted(indices, key=lambda i: (-float(valores[i]), -len(codigos[i]), codigos[i]))[:cantidad]
        for i in indices:
            valor = float(valores[i])
            if i not in mejores or valor > mejores[i]:
                mejores[i] = valor
    orden = sorted(mejores, key=lambda i: (-mejores[i], -len(codigos[i]), codigos[i]))[:top_k]
    return [
        {"codigo": codigos[i], "descripcion": descripciones[i],
         "metodo": "tfidf_catalogo", "similitud": round(mejores[i], 4)}
        for i in orden
    ]
