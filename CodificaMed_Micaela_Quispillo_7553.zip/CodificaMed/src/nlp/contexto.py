"""Localiza indicios textuales de contexto, sin interpretar diagnósticos."""
from __future__ import annotations
import re

# El resultado son marcadores, NO un diagnóstico automático de toda la frase.
_CUES = {
    "descartado": (
        "se descarta", "se descartan", "se excluye", "se excluyen",
        "diagnóstico descartado", "diagnostico descartado",
    ),
    "negado": (
        "no se evidencia", "no se evidencian", "no se observa", "no se observan",
        "sin evidencia de", "sin signos de", "sin datos de", "no presenta",
        "no presentan", "no refiere", "no hay", "no tiene", "no padece",
        "niega", "niegan", "ausencia de", "negativo para",
    ),
    "confirmacion": (
        "se confirma", "confirma", "se diagnostica", "diagnosticado", "diagnosticada",
    ),
    "sospecha": ("se sospecha", "sospecha de", "posible", "compatible con"),
    "antecedente": ("antecedente de", "antecedentes de", "historia previa de"),
}

_PATRONES = sorted(
    ((tipo, disparador, re.compile(r"(?<!\w)" + re.escape(disparador) + r"(?!\w)", re.I))
     for tipo, frases in _CUES.items() for disparador in frases),
    key=lambda fila: len(fila[1]), reverse=True,
)


def detectar_marcadores(fragmento: str) -> list[dict[str, object]]:
    """Devuelve tipo, disparador y offsets relativos del fragmento original.

    Dos marcadores de tipos distintos pueden coexistir en un mismo fragmento.
    No se atribuyen estados a enfermedades sin analizar su alcance.
    """
    if not isinstance(fragmento, str):
        raise TypeError("El fragmento debe ser texto")
    marcadores: list[dict[str, object]] = []
    ocupados: list[tuple[int, int]] = []
    for tipo, disparador, patron in _PATRONES:
        for match in patron.finditer(fragmento):
            a, b = match.span()
            if any(a < y and b > x for x, y in ocupados):
                continue
            marcadores.append({"tipo": tipo, "disparador": fragmento[a:b],
                              "inicio": a, "fin": b})
            ocupados.append((a, b))
    return sorted(marcadores, key=lambda marcador: marcador["inicio"])
