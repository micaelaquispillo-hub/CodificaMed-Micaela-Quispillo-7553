"""Preparación reversible de notas clínicas ficticias en español.

Los fragmentos y posiciones siempre se refieren al texto original.
Este módulo no asigna diagnósticos ni códigos CIE-10.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any

ABREVIATURAS = {
    "HTA": "hipertensión arterial",
    "DM2": "diabetes mellitus tipo 2",
    "DM1": "diabetes mellitus tipo 1",
    "EPOC": "enfermedad pulmonar obstructiva crónica",
    "IRC": "insuficiencia renal crónica",
    "ERC": "enfermedad renal crónica",
    "IAM": "infarto agudo de miocardio",
    "ACV": "accidente cerebrovascular",
}

_SEPARADOR = re.compile(r"(?<=[.!?;])\s+|\n+")
_TOKEN = re.compile(r"\w+(?:[.,]\d+)*|[^\w\s]", flags=re.UNICODE)
_PATRON_ABREVIATURAS = re.compile(
    r"\b(?:" + "|".join(map(re.escape, sorted(ABREVIATURAS, key=len, reverse=True))) + r")\b",
    re.IGNORECASE,
)


def normalizar(texto: str) -> str:
    """Normaliza Unicode, espacios y mayúsculas; NO elimina tildes ni negaciones."""
    if not isinstance(texto, str):
        raise TypeError("La nota clínica debe ser texto")
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", texto)).strip().casefold()


def expandir_abreviaturas(texto: str) -> str:
    """Expande un pequeño vocabulario documentado de abreviaturas frecuentes."""
    if not isinstance(texto, str):
        raise TypeError("La nota clínica debe ser texto")
    return _PATRON_ABREVIATURAS.sub(
        lambda coincidencia: ABREVIATURAS[coincidencia.group().upper()], texto
    )


def segmentar(texto: str) -> list[dict[str, Any]]:
    """Genera fragmentos originales y offsets absolutos [inicio, fin)."""
    if not isinstance(texto, str):
        raise TypeError("La nota clínica debe ser texto")
    salida: list[dict[str, Any]] = []
    inicio = 0
    limites = [m for m in _SEPARADOR.finditer(texto)]
    for coincidencia in limites + [None]:
        fin = coincidencia.start() if coincidencia is not None else len(texto)
        crudo = texto[inicio:fin]
        if crudo.strip():
            izquierda = len(crudo) - len(crudo.lstrip())
            derecha = len(crudo.rstrip())
            a, b = inicio + izquierda, inicio + derecha
            salida.append({"inicio": a, "fin": b, "texto": texto[a:b]})
        if coincidencia is not None:
            inicio = coincidencia.end()
    return salida


def procesar_nota(texto: str) -> dict[str, Any]:
    """Preprocesa la nota sin sustituir su evidencia original."""
    if not isinstance(texto, str):
        raise TypeError("La nota clínica debe ser texto")
    if not texto.strip():
        raise ValueError("La nota clínica no puede estar vacía")
    from src.nlp.contexto import detectar_marcadores

    fragmentos = []
    for fragmento in segmentar(texto):
        original = fragmento["texto"]
        expandido = expandir_abreviaturas(original)
        fragmentos.append({
            **fragmento,
            "texto_preparado": normalizar(expandido),
            "tokens": _TOKEN.findall(normalizar(expandido)),
            "marcadores": detectar_marcadores(original),
        })
    return {"texto_original": texto, "fragmentos": fragmentos}
