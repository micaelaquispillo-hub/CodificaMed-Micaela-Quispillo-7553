"""Detección léxica inicial de expresiones clínicas ficticias.

Los códigos son CANDIDATOS de revisión, no predicciones clínicas validadas.
No se consultan las etiquetas de referencia de los casos.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

from src.nlp.contexto import detectar_marcadores
from src.nlp.preprocesamiento import procesar_nota
from src.retrieval.catalogo import cargar_catalogo

RAIZ = Path(__file__).resolve().parents[2]
RUTA_LEXICO = RAIZ / "data" / "lexico_clinico.json"

# Separadores de alcance: un marcador de negación no se propaga a otra proposición.
_CORTE = re.compile(r"[,;:]|\b(?:pero|sin embargo|aunque|no obstante)\b|\by\s+(?:sí|presenta|tiene|se\s+diagnostica|se\s+confirma)\b", re.I)
_SUFFIX = re.compile(r"^\s+(?:ha\s+sido\s+)?(?:descartad[oa]s?|excluid[oa]s?|no\s+confirmad[oa]s?)\b", re.I)
_NEG_SOLA = re.compile(r"(?:^|[\s,:;])(?:no|sin)\s+(?:\w+\s+){0,3}$", re.I)
_CONTRADICCION = re.compile(r"\bno\s+se\s+descarta\b|\bno\s+se\s+excluye\b", re.I)
_ALCANCE_MAX = 12  # número máximo de palabras entre marcador y expresión


@lru_cache(maxsize=1)
def cargar_lexico() -> tuple[dict, ...]:
    with RUTA_LEXICO.open(encoding="utf-8") as f:
        datos = json.load(f)
    catalogo = cargar_catalogo()
    entradas = []
    for item in datos["entradas"]:
        codigo = item["codigo"]
        if codigo not in catalogo:
            raise ValueError(f"Código del léxico no existe en catálogo: {codigo}")
        if not item.get("sinonimos"):
            raise ValueError(f"No hay expresiones para: {codigo}")
        for alias in item["sinonimos"]:
            if not isinstance(alias, str) or not alias.strip():
                raise ValueError(f"Expresión vacía para: {codigo}")
            # Respeta límites de palabras para no detectar partes de otras palabras.
            entradas.append({
                "concepto": item["concepto"], "codigo": codigo,
                "alias": alias, "patron": re.compile(r"(?<!\w)" + re.escape(alias) + r"(?!\w)", re.I),
            })
    # Preferir expresiones más específicas sobre sus subcadenas.
    return tuple(sorted(entradas, key=lambda x: len(x["alias"]), reverse=True))


def _estado_contexto(texto: str, inicio: int, fin: int) -> str:
    """Reglas conservadoras por mención. No interpreta texto clínico arbitrario."""
    anterior = texto[:inicio]
    posterior = texto[fin:]
    cortes = list(_CORTE.finditer(anterior))
    desde = cortes[-1].end() if cortes else 0
    prefijo = texto[desde:inicio]

    # Evitar clasificar como descartada una expresión con negación doble.
    if _CONTRADICCION.search(prefijo):
        return "revisar"

    if _SUFFIX.match(posterior):
        return "descartado"

    marcadores = detectar_marcadores(prefijo)
    cercanos = [m for m in marcadores if len(prefijo[m["fin"]:].split()) <= _ALCANCE_MAX]
    if cercanos:
        tipo = cercanos[-1]["tipo"]
        return {
            "confirmacion": "confirmado",
            "sospecha": "sospechado",
            "antecedente": "antecedente",
        }.get(tipo, tipo)

    if _NEG_SOLA.search(prefijo):
        return "negado"

    # Sin disparador: presencia textual, pero no diagnóstico confirmado.
    return "sin_contexto"


def detectar_entidades(texto: str) -> list[dict]:
    """Devuelve menciones con offsets verificables y contexto INDICATIVO."""
    procesado = procesar_nota(texto)
    hallazgos = []
    catalogo = cargar_catalogo()
    for segmento in procesado["fragmentos"]:
        original = segmento["texto"]
        ocupados: list[tuple[int, int]] = []
        for entrada in cargar_lexico():
            for match in entrada["patron"].finditer(original):
                a, b = match.span()
                if any(a < y and b > x for x, y in ocupados):
                    continue
                inicio, fin = segmento["inicio"] + a, segmento["inicio"] + b
                contexto = _estado_contexto(original, a, b)
                hallazgos.append({
                    "concepto": entrada["concepto"],
                    "codigo_candidato": entrada["codigo"],
                    "descripcion_catalogo": catalogo[entrada["codigo"]],
                    "expresion": texto[inicio:fin],
                    "evidencia": original,
                    "estado_contextual": contexto,
                    "inicio": inicio, "fin": fin,
                    "inicio_evidencia": segmento["inicio"],
                    "fin_evidencia": segmento["fin"],
                    "metodo": "diccionario_clinico",
                })
                ocupados.append((a, b))
    return sorted(hallazgos, key=lambda x: (x["inicio"], x["fin"]))
