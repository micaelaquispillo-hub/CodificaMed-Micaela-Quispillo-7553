"""Entrada común para los proveedores con recuperación y validación independientes."""
from __future__ import annotations

import os
from time import perf_counter

from src.nlp.entidades import detectar_entidades
from src.nlp.preprocesamiento import procesar_nota
from src.retrieval.catalogo import cargar_catalogo
from .configuracion import cargar_configuracion, crear_proveedor
from .validacion import validar_respuesta


def recuperar_candidatos(texto: str, usar_embeddings: bool = True, limite: int = 15,
                          codificador=None, indice=None) -> list[dict]:
    procesado = procesar_nota(texto)
    catalogo = cargar_catalogo()
    candidatos = {}
    for entidad in detectar_entidades(texto):
        codigo = entidad["codigo_candidato"]
        if codigo not in candidatos:
            candidatos[codigo] = {
                "codigo": codigo, "descripcion": catalogo[codigo],
                "metodo": "lexico", "similitud": None,
            }
    if usar_embeddings:
        if codificador is None or indice is None:
            from src.retrieval.semantica import (
                MODELO_PREDETERMINADO, cargar_modelo, construir_o_cargar_indice
            )
            codificador = cargar_modelo(MODELO_PREDETERMINADO)
            indice, _ = construir_o_cargar_indice(codificador, MODELO_PREDETERMINADO)
        nuevos = {}
        for frag in procesado["fragmentos"]:
            for item in indice.buscar(frag["texto_preparado"], codificador, top_k=3, umbral=0.52):
                codigo = item["codigo_candidato"]
                if codigo in candidatos:
                    continue
                sim = item["similitud"]
                if codigo not in nuevos or sim > nuevos[codigo]["similitud"]:
                    nuevos[codigo] = {
                        "codigo": codigo, "descripcion": catalogo[codigo],
                        "metodo": "embeddings", "similitud": sim,
                    }
        for item in sorted(nuevos.values(), key=lambda x: -x["similitud"]):
            if len(candidatos) >= limite:
                break
            candidatos[item["codigo"]] = item
    # Búsqueda opcional sobre el catálogo completo; desactivada por defecto
    # para mantener reproducible la línea base y las pruebas existentes.
    if os.getenv("CODIFICAMED_TFIDF_CATALOGO", "0") == "1" and len(candidatos) < limite:
        from src.retrieval.busqueda_catalogo import buscar_en_catalogo
        for item in buscar_en_catalogo(procesado["fragmentos"]):
            codigo = item["codigo"]
            if codigo not in candidatos:
                candidatos[codigo] = item
            if len(candidatos) >= limite:
                break
    return list(candidatos.values())[:limite]


def analizar_nota(texto: str, proveedor: str | None = None,
                 usar_embeddings: bool = True, proveedor_obj=None,
                 codificador=None, indice=None) -> dict:
    if not isinstance(texto, str) or not texto.strip():
        raise ValueError("La nota clínica no puede estar vacía")
    if len(texto) > 10000:
        raise ValueError("Límite inicial: máximo 10.000 caracteres por nota ficticia")
    inicio = perf_counter()
    cfg = cargar_configuracion(proveedor)
    candidatos = recuperar_candidatos(
        texto, usar_embeddings=usar_embeddings, codificador=codificador, indice=indice
    )
    if not candidatos:
        return {
            "proveedor": cfg.nombre, "modelo": cfg.modelo, "candidatos": [],
            "diagnosticos": [], "confirmados": [], "para_revision": [], "rechazados": [],
            "duracion_segundos": round(perf_counter() - inicio, 3),
            "advertencia": "No hay candidatos en el léxico; no se consultó ningún modelo.",
        }
    instancia = proveedor_obj if proveedor_obj is not None else crear_proveedor(cfg)
    datos = instancia.analizar(texto, candidatos)
    validados = validar_respuesta(datos, texto, candidatos)
    return {
        "proveedor": cfg.nombre,
        "modelo": cfg.modelo,
        "candidatos": candidatos,
        "duracion_segundos": round(perf_counter() - inicio, 3),
        **validados,
    }
