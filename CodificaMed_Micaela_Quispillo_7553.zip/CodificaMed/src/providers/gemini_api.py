"""Conector real a Gemini API (generateContent), sin dependencias adicionales.

Todos los resultados se validan después con el mismo validador de CodificaMed.
Nunca se envía una clave en parámetros de URL ni en mensajes de error.
"""
from __future__ import annotations

import json
import re

import requests

from .configuracion import ConfigProveedor
from .contrato import ESQUEMA, INSTRUCCIONES, construir_entrada


class GeminiProveedor:
    URL_BASE = "https://generativelanguage.googleapis.com/v1beta/models"

    def __init__(self, configuracion: ConfigProveedor, sesion=None):
        if not configuracion.clave:
            raise ValueError("GEMINI_API_KEY no está configurada en el archivo .env.")
        self.configuracion = configuracion
        self.sesion = sesion if sesion is not None else requests

    def analizar(self, texto: str, candidatos: list[dict]) -> dict:
        cfg = self.configuracion
        if not cfg.modelo or not re.fullmatch(r"[A-Za-z0-9._-]+", cfg.modelo):
            raise ValueError("GEMINI_MODEL no es un identificador de modelo válido.")

        # La API de generateContent admite el subconjunto OpenAPI de respuesta JSON.
        # 'additionalProperties' se omite en la petición; el validador propio
        # conserva el control sobre los códigos, estados y evidencias.
        esquema = {
            "type": "object",
            "properties": {
                "diagnosticos": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": ESQUEMA["properties"]["diagnosticos"]["items"]["properties"],
                        "required": ["codigo", "estado", "evidencia"],
                    },
                },
            },
            "required": ["diagnosticos"],
        }
        config_generacion = {
            "temperature": 0,
            "maxOutputTokens": 2048,
            "responseMimeType": "application/json",
            "responseSchema": esquema,
        }
        if cfg.modelo in {"gemini-2.5-flash", "gemini-2.5-flash-lite"}:
            config_generacion["thinkingConfig"] = {"thinkingBudget": 0}

        cuerpo = {
            "systemInstruction": {"parts": [{"text": INSTRUCCIONES}]},
            "contents": [{"role": "user", "parts": [{"text": construir_entrada(texto, candidatos)}]}],
            "generationConfig": config_generacion,
        }
        try:
            respuesta = self.sesion.post(
                f"{self.URL_BASE}/{cfg.modelo}:generateContent",
                headers={"x-goog-api-key": cfg.clave, "Content-Type": "application/json"},
                json=cuerpo,
                timeout=cfg.timeout,
            )
            respuesta.raise_for_status()
        except requests.exceptions.Timeout as exc:
            raise RuntimeError("Gemini agotó el tiempo de espera; prueba con una nota breve.") from None
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError("No se pudo conectar con Gemini. Revisa la conexión a Internet.") from None
        except requests.exceptions.HTTPError as exc:
            codigo = getattr(getattr(exc, "response", None), "status_code", None)
            if codigo is None:
                codigo = getattr(locals().get("respuesta"), "status_code", None)
            mensajes = {
                400: "Solicitud rechazada: revisa el modelo y la configuración de salida JSON.",
                401: "La clave de Gemini no fue aceptada.",
                403: "La API está restringida, deshabilitada o la clave no tiene permiso.",
                404: "El modelo indicado no existe o no está disponible en este proyecto.",
                429: "Se alcanzó la cuota o el límite de solicitudes del nivel gratuito.",
            }
            raise RuntimeError(f"Gemini HTTP {codigo or 'error'}: {mensajes.get(codigo, 'Error del servicio.')}" ) from None
        except requests.exceptions.RequestException:
            raise RuntimeError("Error de comunicación con Gemini.") from None

        try:
            datos = respuesta.json()
            candidatos_respuesta = datos.get("candidates") or []
            if not candidatos_respuesta:
                raise ValueError("Gemini no generó una respuesta (posible bloqueo o restricción).")
            primero = candidatos_respuesta[0]
            razon = primero.get("finishReason")
            if razon and razon not in {"STOP"}:
                raise ValueError(f"Gemini interrumpió la respuesta ({razon}).")
            partes = primero["content"]["parts"]
            contenido = "".join(p.get("text", "") for p in partes if isinstance(p, dict))
            if not contenido.strip():
                raise ValueError("Gemini no devolvió contenido JSON.")
            resultado = json.loads(contenido)
            if not isinstance(resultado, dict):
                raise ValueError("Gemini no devolvió un objeto JSON.")
            return resultado
        except (KeyError, TypeError, IndexError, json.JSONDecodeError) as exc:
            raise ValueError("Gemini devolvió una respuesta JSON inválida o incompleta.") from None
