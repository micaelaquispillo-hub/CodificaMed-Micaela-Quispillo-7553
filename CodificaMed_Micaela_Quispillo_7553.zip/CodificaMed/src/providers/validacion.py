"""Validación independiente de la respuesta LLM contra catálogo y texto original.

Un JSON estructuralmente válido NO certifica pertinencia clínica. Este control
rechaza códigos inexistentes/no candidatos y evidencias ausentes y comprueba
contradicciones obvias con marcadores léxicos de negación/descarte/sospecha.
"""
from __future__ import annotations

from typing import Any

from src.nlp.entidades import detectar_entidades
from src.retrieval.catalogo import cargar_catalogo
from .contrato import ESTADOS

BLOQUEADOS = {"negado", "descartado", "sospechado", "antecedente", "revisar"}


def validar_respuesta(datos: Any, texto: str, candidatos: list[dict]) -> dict:
    if not isinstance(datos, dict) or not isinstance(datos.get("diagnosticos"), list):
        raise ValueError("El proveedor no devolvió {'diagnosticos': [...]}.")
    catalogo = cargar_catalogo()
    permitidos = {c["codigo"] for c in candidatos}
    # Estado léxico orientativo; por seguridad bloquea contradicciones claras.
    menciones = detectar_entidades(texto)
    validados: list[dict] = []
    rechazados: list[dict] = []
    vistos: set[str] = set()

    for n, item in enumerate(datos["diagnosticos"], 1):
        motivo = ""
        if not isinstance(item, dict):
            rechazados.append({"numero": n, "motivo": "Elemento no es objeto"})
            continue
        codigo, estado, evidencia = item.get("codigo"), item.get("estado"), item.get("evidencia")
        if not isinstance(codigo, str) or codigo not in catalogo:
            motivo = "Código inexistente en el catálogo"
        elif codigo not in permitidos:
            motivo = "Código fuera de los candidatos enviados"
        elif not isinstance(estado, str) or estado not in ESTADOS:
            motivo = "Estado clínico inválido"
        elif not isinstance(evidencia, str) or not evidencia.strip() or evidencia not in texto:
            motivo = "Evidencia no literal o ausente de la nota"
        elif codigo in vistos:
            motivo = "Código duplicado (el sistema entrega un código por nota)"
        else:
            inicio = texto.find(evidencia)
            fin = inicio + len(evidencia)
            if estado == "confirmado":
                # Si la evidencia contiene exactamente una mención marcada como
                # negada/descartada/sospechada, jamás aceptarla como confirmada.
                contradiccion = any(
                    m["codigo_candidato"] == codigo and
                    m["estado_contextual"] in BLOQUEADOS and
                    inicio <= m["inicio"] and m["fin"] <= fin
                    for m in menciones
                )
                if contradiccion:
                    motivo = "Contradice el contexto léxico de la evidencia"

        if motivo:
            rechazados.append({"numero": n, "codigo": codigo if isinstance(codigo, str) else "", "motivo": motivo})
        else:
            vistos.add(codigo)
            validados.append({
                "codigo": codigo,
                "descripcion": catalogo[codigo],
                "estado": estado,
                "evidencia": evidencia,
            })
    return {
        "diagnosticos": validados,
        "confirmados": [x for x in validados if x["estado"] == "confirmado"],
        "para_revision": [x for x in validados if x["estado"] != "confirmado"],
        "rechazados": rechazados,
        "advertencia": "Validación estructural y de contexto inicial; requiere revisión clínica humana.",
    }
