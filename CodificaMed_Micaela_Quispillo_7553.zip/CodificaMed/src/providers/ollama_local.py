"""Conector REAL a Ollama local: POST /api/chat (sin streaming)."""
from __future__ import annotations

import json
import requests

from .configuracion import ConfigProveedor
from .contrato import ESQUEMA, INSTRUCCIONES, construir_entrada


class OllamaProveedor:
    def __init__(self, configuracion: ConfigProveedor, sesion=None):
        self.configuracion = configuracion
        self.sesion = sesion or requests

    def analizar(self, texto: str, candidatos: list[dict]) -> dict:
        cfg = self.configuracion
        if not cfg.modelo or not cfg.base_url:
            raise ValueError("Ollama necesita OLLAMA_MODEL y OLLAMA_BASE_URL.")
        cuerpo = {
            "model": cfg.modelo,
            "stream": False,
            "format": ESQUEMA,
            "messages": [
                {"role": "system", "content": INSTRUCCIONES},
                {"role": "user", "content": construir_entrada(texto, candidatos)},
            ],
            "options": {"temperature": 0},
        }
        try:
            respuesta = self.sesion.post(
                f"{cfg.base_url}/api/chat", json=cuerpo, timeout=cfg.timeout
            )
            respuesta.raise_for_status()
            contenido = respuesta.json()["message"]["content"]
            if not isinstance(contenido, str) or not contenido.strip():
                raise ValueError("Ollama no devolvió contenido JSON.")
            return json.loads(contenido)
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError("No hay conexión con Ollama. Abre Ollama y comprueba 'ollama list'.") from exc
        except requests.exceptions.Timeout as exc:
            raise RuntimeError("Ollama agotó el tiempo de espera. Usa una nota más corta o revisa el modelo.") from exc
        except requests.exceptions.HTTPError as exc:
            raise RuntimeError(f"Ollama rechazó la solicitud: {exc}. Comprueba 'ollama list'.") from exc
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError("Ollama devolvió una respuesta sin el JSON esperado.") from exc
