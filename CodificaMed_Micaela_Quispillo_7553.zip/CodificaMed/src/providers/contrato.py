"""Contrato de salida compartido por Ollama, OpenAI y Gemini."""
from __future__ import annotations

ESTADOS = ("confirmado", "negado", "descartado", "sospechado", "antecedente", "revisar")

ESQUEMA = {
    "type": "object",
    "properties": {
        "diagnosticos": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "codigo": {"type": "string"},
                    "estado": {"type": "string", "enum": list(ESTADOS)},
                    "evidencia": {"type": "string"},
                },
                "required": ["codigo", "estado", "evidencia"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["diagnosticos"],
    "additionalProperties": False,
}

INSTRUCCIONES = """Eres un asistente para codificación CIE-10 de NOTAS CLÍNICAS FICTICIAS en español.
Devuelve EXCLUSIVAMENTE un objeto JSON válido que cumpla el esquema proporcionado.
No diagnostiques enfermedades que no estén expresadas en la nota. Solo puedes usar códigos de
la lista CANDIDATOS. No inventes códigos. Un candidato recuperado NO prueba un diagnóstico.
Asocia a cada código la evidencia LITERAL, exacta y continua tomada del texto original.
No reformules las evidencias, no cambies tildes, letras ni puntuación.
Clasifica cada mención como confirmado, negado, descartado, sospechado, antecedente o revisar.
No trates un hallazgo aislado o 'sin contexto' como confirmación automática: ante incertidumbre
usa revisar o devuelve una lista vacía. No clasifiques como confirmado un diagnóstico negado,
descartado, sospechado o de antecedentes. No infieras complicaciones solo por la enfermedad base.
Las notas son ficticias y la sugerencia necesita validación humana.
"""


def construir_entrada(texto: str, candidatos: list[dict]) -> str:
    import json
    permitidos = [
        {"codigo": c["codigo"], "descripcion_catalogo": c["descripcion"]}
        for c in candidatos
    ]
    return (
        "Analiza esta nota clínica ficticia y responde con JSON. "
        "No incluyas códigos fuera de los candidatos.\n"
        "NOTA_ORIGINAL: " + json.dumps(texto, ensure_ascii=False) + "\n"
        "CANDIDATOS: " + json.dumps(permitidos, ensure_ascii=False)
    )
