"""Configuración externa sin claves ni valores privados en el repositorio."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

RAIZ = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class ConfigProveedor:
    nombre: str
    modelo: str
    timeout: float
    base_url: str = ""
    clave: str = ""


def cargar_configuracion(proveedor: str | None = None) -> ConfigProveedor:
    load_dotenv(RAIZ / ".env", override=False)
    nombre = (proveedor or os.getenv("LLM_PROVIDER", "ollama")).strip().lower()
    if nombre == "ollama":
        return ConfigProveedor(
            nombre="ollama",
            modelo=os.getenv("OLLAMA_MODEL", "qwen2.5:3b").strip(),
            base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").strip().rstrip("/"),
            timeout=180.0,
        )
    if nombre == "openai":
        return ConfigProveedor(
            nombre="openai",
            modelo=os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip(),
            clave=os.getenv("OPENAI_API_KEY", "").strip(),
            timeout=90.0,
        )
    if nombre == "gemini":
        return ConfigProveedor(
            nombre="gemini",
            modelo=os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip(),
            clave=os.getenv("GEMINI_API_KEY", "").strip(),
            timeout=90.0,
        )
    raise ValueError("Proveedor no admitido: usa 'ollama', 'openai' o 'gemini'.")


def crear_proveedor(cfg: ConfigProveedor):
    if cfg.nombre == "ollama":
        from .ollama_local import OllamaProveedor
        return OllamaProveedor(cfg)
    if cfg.nombre == "openai":
        from .openai_api import OpenAIProveedor
        return OpenAIProveedor(cfg)
    if cfg.nombre == "gemini":
        from .gemini_api import GeminiProveedor
        return GeminiProveedor(cfg)
    raise ValueError(f"Proveedor desconocido: {cfg.nombre}")
