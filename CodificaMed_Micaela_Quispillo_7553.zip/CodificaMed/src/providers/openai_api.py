"""Conector REAL a OpenAI Responses API, con salida JSON restringida."""
from __future__ import annotations

import json

from .configuracion import ConfigProveedor
from .contrato import ESQUEMA, INSTRUCCIONES, construir_entrada


class OpenAIProveedor:
    def __init__(self, configuracion: ConfigProveedor, cliente=None):
        self.configuracion = configuracion
        if cliente is not None:
            self.cliente = cliente
            return
        if not configuracion.clave:
            raise ValueError("OPENAI_API_KEY no está configurada en el archivo .env.")
        from openai import OpenAI
        self.cliente = OpenAI(api_key=configuracion.clave, timeout=configuracion.timeout,
                             max_retries=1)

    def analizar(self, texto: str, candidatos: list[dict]) -> dict:
        try:
            respuesta = self.cliente.responses.create(
                model=self.configuracion.modelo,
                instructions=INSTRUCCIONES,
                input=construir_entrada(texto, candidatos),
                text={"format": {
                    "type": "json_schema",
                    "name": "codificamed_diagnosticos",
                    "strict": True,
                    "schema": ESQUEMA,
                }},
                max_output_tokens=1400,
                store=False,
            )
        except Exception as exc:
            # No imprimir el objeto exc completo: podría contener detalles de la solicitud.
            raise RuntimeError(
                f"Error de OpenAI ({type(exc).__name__}). Comprueba API key, créditos, modelo y conexión."
            ) from None
        contenido = getattr(respuesta, "output_text", "")
        if not isinstance(contenido, str) or not contenido.strip():
            raise ValueError("OpenAI no devolvió texto JSON (posible rechazo o salida incompleta).")
        try:
            return json.loads(contenido)
        except json.JSONDecodeError as exc:
            raise ValueError("OpenAI devolvió una salida JSON inválida o truncada.") from exc
