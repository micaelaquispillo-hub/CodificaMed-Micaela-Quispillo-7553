"""Preparación de resultados de CodificaMed para la interfaz.

Este módulo no hace inferencia ni cambia diagnósticos; solo organiza resultados
recibidos del pipeline y permite exportar revisiones humanas en CSV.
"""
from __future__ import annotations

import csv
from io import StringIO
from typing import Any


CAMPOS_DIAGNOSTICO = ("codigo", "descripcion", "estado", "evidencia")


def preparar_revision(resultado: dict[str, Any]) -> list[dict[str, Any]]:
    """Lista editable: marcar 'revisado' no cambia el estado clínico."""
    diagnosticos = resultado.get("diagnosticos", [])
    if not isinstance(diagnosticos, list):
        raise ValueError("Los diagnósticos deben ser una lista")
    filas = []
    for item in diagnosticos:
        if not isinstance(item, dict):
            raise ValueError("Diagnóstico con formato incorrecto")
        filas.append({
            **{campo: str(item.get(campo, "")) for campo in CAMPOS_DIAGNOSTICO},
            "revisado": False,
        })
    return filas


def resumen_estados(resultado: dict[str, Any]) -> dict[str, int]:
    diagnosticos = resultado.get("diagnosticos", [])
    return {
        "total": len(diagnosticos),
        "confirmados": sum(d.get("estado") == "confirmado" for d in diagnosticos),
        "otros_estados": sum(d.get("estado") != "confirmado" for d in diagnosticos),
        "rechazados": len(resultado.get("rechazados", [])),
        "candidatos": len(resultado.get("candidatos", [])),
    }


def exportar_csv_revision(filas: list[dict[str, Any]], solo_revisados: bool = True) -> bytes:
    """Exporta sin incluir notas completas, claves ni información de configuración."""
    texto = StringIO(newline="")
    campos = [*CAMPOS_DIAGNOSTICO, "revisado"]
    escritor = csv.DictWriter(texto, fieldnames=campos, delimiter=";", lineterminator="\n")
    escritor.writeheader()
    for fila in filas:
        if solo_revisados and not bool(fila.get("revisado", False)):
            continue
        escritor.writerow({
            **{campo: str(fila.get(campo, "")) for campo in CAMPOS_DIAGNOSTICO},
            "revisado": "si" if bool(fila.get("revisado", False)) else "no",
        })
    return ("\ufeff" + texto.getvalue()).encode("utf-8")
