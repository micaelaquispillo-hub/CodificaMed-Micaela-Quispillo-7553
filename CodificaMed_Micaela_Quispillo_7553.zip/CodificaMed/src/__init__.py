"""
CodificaMed — Motor de codificación clínica CIE-10
"""

__version__ = "0.1.0"

