# Paso 10 — Evaluación cuantitativa provisional (CRISP-ML(Q))

## Objetivo

Comparar los dos proveedores **reales** ya probados (Ollama y Gemini) sobre las **mismas notas ficticias**. La evaluación usa coincidencia **exacta** del código CIE-10 **confirmado** por nota; los códigos negados, descartados, sospechados o en antecedentes no se consideran positivos. Si un proveedor confirma un código negado en la referencia, cuenta como falso positivo.

**ATENCIÓN:** Las 10 notas contienen etiquetas de referencia pendientes de revisión clínica: se han identificado posibles problemas, por ejemplo en códigos de fractura y secuelas cerebrovasculares, y el catálogo inicial de embeddings cubre **solo 28 códigos**. Por lo tanto, los puntajes serán **provisionales**. No presentarlos como calidad clínica final.

## Instalación

Aplicar el ZIP de este paso **sobre la raíz** de `CodificaMed` en la que ya funcionan Ollama y Gemini. No trabajar desde la carpeta del ZIP aislado. No sobrescribe `.env`, `.gitignore`, `models_cache` ni datos anteriores.

## Comandos PowerShell

Primero comprobar la integridad de las pruebas y ver qué se ejecutaría sin consumir cuota:

```powershell
python -m unittest discover -s tests -p "test_*.py" -v
python .\scripts\evaluar_modelos.py --solo-preparar --limite 1
```

Cuando la API de Gemini tenga cuota disponible y Ollama esté iniciado, evaluar **una sola nota**, con recuperación semántica activada:

```powershell
python .\scripts\evaluar_modelos.py --proveedores gemini ollama --limite 1
```

Para el resto del conjunto, **después de revisar las etiquetas de referencia**:

```powershell
python .\scripts\evaluar_modelos.py --proveedores gemini ollama --limite 10
```

La última opción puede realizar hasta **20 inferencias**, consumir cuota de Gemini y tardar varios minutos con Ollama. No ejecutarla antes de revisar etiquetas y disponibilidad de recursos. Si falla un proveedor, se registra como error y **no** como predicción vacía. La comparación utiliza solamente notas que se ejecutaron correctamente con **ambos** proveedores.

## Archivos de resultados

Se crean dos archivos con fecha y hora UTC en `data/resultados/`:

- JSON: configuración, modelos, duraciones, resultados por nota, VP/FP/FN y micro-precisión/recall/F1 del subconjunto comparable.
- CSV: una fila por nota y proveedor para revisar, filtrar o incorporar tablas al informe.

No se guardan las notas originales, las claves API ni los textos de respuesta. Cada archivo indica que los resultados son **provisionales**. Conserva las salidas anteriores para comparar cambios; no selecciones únicamente las ejecuciones favorables.

Si no hay ninguna nota evaluable, las métricas no definidas se muestran como `null`/`None`, nunca como 100%.

## Antes de completar el informe

1. Revisar y corregir códigos/estados contra una **única** edición documentada del catálogo, sin cambiar etiquetas para favorecer al modelo.
2. Ampliar el conjunto de evaluación con notas ficticias independientes y distintos escenarios; 10 notas de ejemplo no bastan para una conclusión sólida.
3. Ejecutar ambos proveedores en el mismo conjunto, con los mismos candidatos y la misma configuración de embeddings.
4. Informar cobertura del catálogo, errores, abstenciones y tiempos, además de las métricas.

El sistema es **académico** y no debe emplearse para codificar historias clínicas de pacientes reales.
