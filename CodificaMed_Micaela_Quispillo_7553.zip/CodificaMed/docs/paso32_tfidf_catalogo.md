# Paso 32 — Recuperación TF-IDF del catálogo CIE-10

## Propósito

Agregar una vía de búsqueda léxica que consulta las 98.288 descripciones del
catálogo CIE-10 local. No modifica el vocabulario manual ni consulta etiquetas
`codigos_esperados` al recuperar candidatos.

## Activación

La búsqueda está apagada de forma predeterminada para conservar los resultados
anteriores. En PowerShell, dentro del proyecto:

```powershell
$env:CODIFICAMED_TFIDF_CATALOGO = "1"
python .\scripts\medir_cobertura_tfidf.py
```

Para desactivar la mejora en esa terminal:

```powershell
Remove-Item Env:CODIFICAMED_TFIDF_CATALOGO -ErrorAction SilentlyContinue
```

Se necesitan `scikit-learn`, `numpy` y `scipy`, ya presentes en este entorno.
El índice TF-IDF se construye en RAM una sola vez por proceso; no descarga
modelos ni crea archivos grandes en disco.

## Evaluación

`python .\scripts\medir_cobertura_tfidf.py` compara cobertura del conjunto
de códigos confirmados con y sin TF-IDF. No consulta proveedores ni consume cuota.

Resultado exploratorio observado con las 10 notas revisadas:
- Léxico original: 6 de 16 diagnósticos confirmados (37,5 %).
- Léxico + TF-IDF: 12 de 16 (75,0 %).

Son métricas de recuperación de candidatos, NO de predicción de diagnósticos
ni métricas finales del LLM. Las notas han servido para diagnosticar el sistema;
no deben presentarse como un conjunto de prueba independiente.

## Precauciones

La búsqueda produce candidatos potencialmente irrelevantes. El límite total
de candidatos sigue siendo 15 por nota y la validación de códigos, estados y
evidencias permanece activa. Los conceptos ausentes o expresados mediante
sinónimos no presentes en el catálogo pueden seguir sin recuperarse. No se debe
retocar el ground truth para incrementar las puntuaciones.

Los resultados de evaluación posteriores registran `busqueda_tfidf_catalogo`
en el JSON para distinguirlos de la línea base.
