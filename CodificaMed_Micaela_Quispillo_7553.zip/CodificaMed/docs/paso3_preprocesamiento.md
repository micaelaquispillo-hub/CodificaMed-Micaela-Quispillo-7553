# Paso 3: preprocesamiento inicial de PLN

Cambios realizados:
- Se crea `src/nlp/preprocesamiento.py` para normalizar, expandir abreviaturas y segmentar conservando posiciones del texto original.
- Se crea `src/nlp/contexto.py` para detectar marcadores de confirmación, negación, descarte, sospecha y antecedentes.
- Se crea `scripts/demo_preprocesamiento.py` para ejecutar las diez notas ficticias.
- Se añaden pruebas unitarias en `tests/test_nlp.py`.
- Se reclasifican como `descartado` cuatro etiquetas que contienen la evidencia literal «Se descarta ...». No se modificaron códigos ni descripciones.

**Límite técnico:** detectar un marcador no es equivalente a identificar una enfermedad, resolver el alcance de la negación o asignar un código CIE-10. En textos complejos puede haber dos marcadores de distinto tipo dentro del mismo fragmento. La vinculación precisa entre diagnóstico y contexto se implementará en el pipeline posterior.

**Límite clínico:** los códigos de las notas aún requieren revisión de pertinencia y granularidad antes de calcular métricas finales.

## Verificación en PowerShell (desde la raíz del proyecto)

```powershell
python .\scripts\validate_codes.py
python .\scripts\auditar_notas.py
python -m unittest discover -s tests -p test_nlp.py -v
python .\scripts\demo_preprocesamiento.py
```

La auditoría debe terminar con 25 confirmados, 8 negados y 4 descartados, sin problemas estructurales. Las pruebas automatizadas deben informar `OK`. La demostración debe procesar 10 notas sin alterar las evidencias originales.
