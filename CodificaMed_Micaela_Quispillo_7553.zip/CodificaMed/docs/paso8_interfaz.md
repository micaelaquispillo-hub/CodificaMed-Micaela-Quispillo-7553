# Paso 8 — Interfaz de CodificaMed con Streamlit

## Qué se implementó

- Campo para una **nota clínica ficticia** (máximo 10.000 caracteres), con confirmación expresa de que no contiene información de pacientes reales.
- Selector de proveedor: Ollama, Gemini u OpenAI. El modelo se lee del archivo privado `.env`.
- Opción de ejecutar la recuperación semántica, encendida por defecto.
- Procesamiento con el **mismo pipeline** que `scripts/demo_proveedores.py`. No se utilizan respuestas pregrabadas.
- Resultados diferenciados entre **confirmados** y **otros estados** (negado, descartado, sospechado, antecedente, revisar).
- Visualización de códigos candidatos, evidencia literal, elementos rechazados y tiempos medidos.
- Revisión manual: el usuario puede marcar las sugerencias comprobadas. Marcar un registro no cambia el estado del diagnóstico. Descarga CSV opcional únicamente con registros revisados.
- Caché de recursos en memoria de Streamlit para evitar cargar el modelo de embeddings en cada interacción; sigue reutilizando la carpeta `models_cache` ya vinculada.
- Nueve pruebas nuevas para las utilidades de presentación y exportación, sin llamadas reales a servicios.

## Instalar sin perder el paso 7

**No abras el ZIP del parche como proyecto independiente.** Copia los archivos del parche directamente sobre la carpeta raíz del proyecto completo del paso 7 (que se llama todavía `CodificaMed_paso6_proveedores\\CodificaMed`). No modificar ni eliminar `.env` o `models_cache`.

Desde PowerShell dentro de esa carpeta:

```powershell
Expand-Archive -Path "$HOME\Downloads\CodificaMed_paso8_parche_interfaz.zip" -DestinationPath . -Force
python -m unittest discover -s tests -p "test_*.py" -v
python -m streamlit run app.py
```

Abrir la dirección local que indica Streamlit, normalmente `http://localhost:8501`. La primera inferencia con embeddings puede tardar más porque carga el modelo. La API externa requiere Internet y estar dentro de la cuota del proyecto; Ollama requiere tener el servicio local abierto.

## Prueba sugerida

Nota de ejemplo:

> Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía.

1. Selecciona Gemini y deja activado *Usar recuperación semántica*.
2. Marca la confirmación de que el texto es ficticio.
3. Pulsa **Analizar nota**.
4. Comprueba que aparecen los resultados del backend; el modelo puede devolver una lista diferente en cada ejecución.
5. Revisa los estados y evidencias; marca manualmente solamente las sugerencias comprobadas.
6. Repite la misma nota con Ollama. Guarda capturas auténticas y los tiempos observados.

## Limitaciones

- Las sugerencias no equivalen a diagnósticos médicos válidos. Requieren revisión humana.
- La búsqueda semántica actual utiliza un índice pequeño de 28 códigos, no todo el catálogo.
- La presentación no calcula precisión, recall ni F1. Esas métricas se incorporarán con un conjunto de evaluación clínicamente revisado e independiente.
- La exportación CSV incluye códigos, estados y fragmentos literales de la nota. No se deben ingresar datos reales de pacientes.
- No muestra claves API. Conservar `.env` fuera de GitHub y no compartir capturas de secretos.
