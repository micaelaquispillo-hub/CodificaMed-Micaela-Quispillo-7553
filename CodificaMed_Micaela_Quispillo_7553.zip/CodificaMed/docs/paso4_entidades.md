# Paso 4: reconocimiento inicial de expresiones clínicas

## Alcance

Se implementó un **detector léxico**, basado en un diccionario clínico pequeño, que encuentra expresiones o abreviaturas explícitas en notas ficticias y genera un **código candidato**, no una codificación médica definitiva.

Se agregó:

- `data/lexico_clinico.json`: 28 conceptos, con sinónimos y un código candidato verificado contra `cie10_catalog.csv`.
- `src/retrieval/catalogo.py`: lectura del catálogo local y consulta de descripciones.
- `src/nlp/entidades.py`: detección de menciones con offsets literales y análisis contextual inicial por mención.
- `scripts/demo_entidades.py`: demostración reproducible sobre las diez notas ficticias.
- `tests/test_entidades.py`: 13 nuevas pruebas unitarias.

El reconocimiento **no consulta** el campo `codigos_esperados` durante la inferencia. Las reglas y el vocabulario fueron elaborados a partir de ejemplos del proyecto, por lo que estas diez notas **no constituyen una evaluación independiente** de la calidad de la solución.

## Ejecución

Desde la carpeta raíz `CodificaMed`:

```powershell
python -m unittest discover -s tests -p "test_*.py" -v
python .\scripts\demo_entidades.py
```

Verificación esperada en esta versión: 21 pruebas correctas, diez notas procesadas y 29 expresiones localizadas. Los recuentos son resultados de la ejecución de esta revisión, no métricas de precisión/recall/F1.

## Limitaciones relevantes

- Se identifican solamente expresiones textuales presentes en el diccionario (no es NER entrenado ni embeddings).
- `sin_contexto` significa que no hay un marcador lingüístico inequívoco en las reglas; **no equivale a diagnóstico confirmado**.
- El estado `sospechado` no debe considerarse diagnóstico confirmado ni convertirse automáticamente en facturación.
- La negación y el descarte se detectan mediante reglas que pueden fallar ante oraciones extensas o sintaxis compleja. Se deja `revisar` en contextos ambiguos identificados.
- El código devuelto es un candidato de revisión. Algunas entradas son categorías, no códigos terminales. No se debe calcular todavía F1 clínica, ni usarlo en atención real.
- La procedencia y revisión exacta del catálogo y las etiquetas ficticias requieren auditoría antes de definir una evaluación final; consultar `docs/revision_etiquetas_paso2.md`.

## Lo siguiente

Incorporar recuperación semántica con embeddings sin consultar etiquetas esperadas; separar casos usados para construir el vocabulario de notas de evaluación; revisar equivalencia entre códigos de categoría y códigos completos; conectar ambos proveedores con validación estricta de salida.
