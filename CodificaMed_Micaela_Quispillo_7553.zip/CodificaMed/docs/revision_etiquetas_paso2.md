# Revision de etiquetas clinicas - Paso 2

Este paso parte del proyecto con catalogo reparado. Las notas son **ficticias** y las etiquetas tienen fines de demostracion de PLN, no de codificacion medica real.

## Cambios iniciales aplicados

- nota_003: `E66.01` -> `E66.9`; evidencia conservada: «obesidad grado I con índice de masa corporal de 32»
- nota_005: `R45.85` -> `R45.851`; evidencia conservada: «Niega ideación suicida»
- nota_010: `J44.1` -> `J44.9`; evidencia conservada: «enfermedad pulmonar obstructiva crónica moderada»
- nota_010: `F17.21` -> `Z72.0`; evidencia conservada: «fumador activo de 20 cigarrillos diarios desde hace 25 años»

Se sincronizo `descripcion_es` de cada etiqueta con la descripcion existente para ese codigo en `cie10_catalog.csv`. Esto solo garantiza consistencia textual, no exactitud clinica.

## Revisiones pendientes antes de calcular Precision/Recall/F1

- `nota_008`: `I63` es un infarto cerebral agudo, pero la nota registra secuelas de uno ocurrido hace dos anos. `G81` tampoco expresa por si mismo el origen postinfarto. Revisar la familia `I69.35x` y la informacion de lateralidad/dominancia con una fuente de codificacion oficial.
- `nota_006`: `S52.30` es una categoria incompleta para el detalle de lateralidad y contacto de una fractura cerrada de radio izquierdo; revisar si se debe especificar un codigo terminal. La causa externa `V29.9` tambien requiere revisar informacion disponible y especificidad.
- `nota_009`: `N92.0` presupone ciclo menstrual regular, mientras el texto no aclara regularidad. Revisar contra el motivo de consulta y opciones del catalogo.
- `nota_001`: los codigos `E11` y `E11.40` pueden representar niveles jerarquicos de una misma enfermedad; decidir si se evaluara solo codigos terminales y revisar combinaciones.
- `nota_002`: la descripcion clinica dice *compatible con neumonia bacteriana*; decidir si la anotacion debe tratarla como diagnostico confirmado o sospechado, segun reglas acordadas para casos ficticios.
- Todas las notas: definir una politica consistente sobre codigos de categoria (por ejemplo `K35`, `D25`, `J00`) frente a codigos terminales. No mezclar granularidades al evaluar coincidencias exactas.

## Limitacion conocida de `validate_codes.py`

Ese script prueba la existencia del codigo en el catalogo, **no** prueba la pertinencia clinica ni la politica de codificacion. La nueva auditoria valida estructura, descripcion y evidencia literal, pero sigue sin sustituir la revision clinica.

## Verificacion

Desde la raiz del proyecto:

```powershell
python .\scripts\validate_codes.py
python .\scripts\auditar_notas.py
```

Los comandos deben finalizar sin errores estructurales. No interpretar `Problemas estructurales: 0` como validacion medica de las etiquetas.
