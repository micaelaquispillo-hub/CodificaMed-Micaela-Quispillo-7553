# Paso 5 — Recuperación semántica con embeddings

## Alcance implementado

- `src/retrieval/semantica.py` permite cargar el modelo multilingüe `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`, vectorizar los términos clínicos y sus descripciones, conservar un índice local `.npz` y calcular similitud coseno entre una consulta y cada documento.
- `scripts/demo_semantica.py` hace una búsqueda **con embeddings reales** después de instalar `sentence-transformers` y descargar el modelo.
- `tests/test_semantica.py` comprueba la lógica de normalización, ranking, deduplicación, persistencia, caché e invalidación usando vectores **simulados**. Estas pruebas NO demuestran calidad semántica.
- El índice se construye únicamente sobre los códigos del léxico clínico de ejemplo (28 códigos), aunque el catálogo de respaldo tiene 98.288. No afirma cobertura del catálogo completo.
- Las etiquetas `codigos_esperados` del conjunto de notas no se consultan para generar resultados.

## Instalación y ejecución en Windows 11

Desde la raíz `CodificaMed` en VS Code:

```powershell
python -m pip install -r requirements.txt
python -m unittest discover -s tests -p "test_*.py" -v
python .\scripts\demo_semantica.py --consulta "Paciente con hipertensión arterial persistente"
```

La primera ejecución del último comando necesita conexión a Internet para descargar el modelo desde Hugging Face. Si falla, comprobar instalación, conectividad, RAM y que el antivirus/proxy no bloquee la descarga. Los archivos quedan en `models_cache/`, excluida de Git.

Para probar otra frase sin recrear los vectores:

```powershell
python .\scripts\demo_semantica.py --consulta "Paciente con diabetes tipo dos"
```

Debería indicarse `cargado desde caché` en la segunda ejecución con el mismo modelo y el mismo léxico. El ranking exacto y sus similitudes deben comprobarse en el equipo donde se ejecute el modelo real; no se han probado en el entorno de preparación de este ZIP, ya que allí no está instalado `sentence-transformers`.

El valor de `similitud` mide semejanza vectorial, **no** es una probabilidad de diagnóstico ni debe interpretarse como fiabilidad clínica. El campo `estado` se mantiene como `requiere_revision`. Si el texto dice «niega neumonía», una semejanza alta con «neumonía» no autoriza a codificar el diagnóstico como confirmado.

## Evidencia sugerida

- `E05_pruebas_modulo_semantico.png`: la terminal con todas las pruebas correctas.
- `E06_recuperacion_embeddings_real.png`: la terminal ejecutando `demo_semantica.py` después de descargar y cargar el modelo real.
- `E07_cache_semantica.png`: segunda ejecución indicando reutilización del índice.

## Pendiente para fases posteriores

1. Revisar las etiquetas de referencia y la edición real del catálogo. Algunas etiquetas de las diez notas todavía presentan problemas clínicos.
2. Extender con cuidado el vocabulario o crear un índice completo por lotes, una vez comprobados tiempos y memoria.
3. Extraer menciones clínicas y analizar su contexto antes de asignar estado y código definitivo.
4. Conectar los proveedores Ollama y API externa con el mismo esquema de entrada, y medir precisión, recall y F1 en notas independientes.
5. Crear interfaz, README final, informe, video y repositorio.

**No introducir historias clínicas reales en la aplicación ni enviarlas a un proveedor externo.**
