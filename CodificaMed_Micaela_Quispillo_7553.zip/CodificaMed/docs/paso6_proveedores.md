# Paso 6 — Proveedores de modelos y validación

## Objetivo

Mantener un único pipeline: nota ficticia → extracción léxica → recuperación semántica (subconjunto de 28 códigos) → proveedor local o API → validación → candidatos con evidencia. **Todavía no existe interfaz ni evaluación clínica independiente.**

## Archivos implementados

- `src/providers/configuracion.py`: lectura de `.env` y selección sin editar código.
- `src/providers/contrato.py`: esquema JSON único e instrucciones de codificación conservadoras.
- `src/providers/ollama_local.py`: POST real a `/api/chat` de Ollama local.
- `src/providers/openai_api.py`: `client.responses.create`, JSON Schema y `store=False`.
- `src/providers/pipeline.py`: combina léxico, embeddings y proveedor.
- `src/providers/validacion.py`: rechaza códigos fuera del catálogo/lista, evidencia inexistente, duplicados y contradicciones léxicas claras.
- `scripts/verificar_proveedores.py`: conexión Ollama y lectura local de clave API (no llama a API externa).
- `scripts/demo_proveedores.py`: inferencia real con la misma nota ficticia.
- `tests/test_proveedores.py`: pruebas sin redes, utilizando respuestas inyectadas; NO son inferencias reales.

## Instalación y preparación (PowerShell)

Abre la carpeta raíz de `CodificaMed` en VS Code y usa un entorno virtual cuando sea posible:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -p "test_*.py" -v
```

Si ya usas Python instalado y prefieres ejecutar con `python`, mantén ese mismo intérprete para todos los comandos.

Crea el archivo privado `.env` a partir del ejemplo:

```powershell
Copy-Item .env.example .env
```

No pegues claves de API en mensajes, capturas, commits ni informes. No subas `.env` a GitHub.

### Ollama local

1. Instala Ollama para Windows desde https://ollama.com/download.
2. Inicia Ollama. En PowerShell:

```powershell
ollama --version
ollama pull qwen2.5:3b
ollama list
python .\scripts\verificar_proveedores.py --proveedor ollama
```

3. Ejecuta una nota **ficticia** sin embeddings, para aislar el modelo:

```powershell
python .\scripts\demo_proveedores.py --proveedor ollama --sin-embeddings --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

4. Prueba el pipeline completo con embeddings:

```powershell
python .\scripts\demo_proveedores.py --proveedor ollama --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

Si `ollama list` indica que no existe el modelo, ejecuta nuevamente `ollama pull qwen2.5:3b`. El modelo es multilingüe y tiene unos 1,9 GB de descarga, además de memoria de ejecución.

### OpenAI API (externa)

1. Usa una API key válida de una cuenta con facturación habilitada cuando corresponda.
2. En `.env` cambia `LLM_PROVIDER=openai` si quieres que sea el proveedor predeterminado y agrega la clave en `OPENAI_API_KEY=` (no la compartas). Mantén `OPENAI_MODEL=gpt-4o-mini` o usa un modelo compatible con JSON Schema.
3. Verifica que Python puede leer la clave sin imprimirla:

```powershell
python .\scripts\verificar_proveedores.py --proveedor openai
```

4. Ejecuta **la misma nota ficticia**:

```powershell
python .\scripts\demo_proveedores.py --proveedor openai --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

**La llamada externa tiene costo potencial.** La prueba de configuración no consume tokens, pero `demo_proveedores.py` sí envía la nota al servicio externo. Nunca envíes historias reales.

## Qué debe observarse

Se imprime proveedor, modelo, número de candidatos, tiempo, estado, código, descripción del catálogo, evidencia literal y sugerencias rechazadas. Los estados no confirmados aparecen como revisión. Los modelos pueden abstenerse: no se garantiza un número de diagnósticos.

## Límites y asuntos pendientes

- El índice solo contiene 28 códigos del léxico (65 documentos), no todo el catálogo de 98.288 códigos.
- El sistema de reglas es básico, y algunas menciones quedan en `sin_contexto`; el LLM puede cometer errores clínicos. La validación evita errores obvios, no certifica la corrección médica.
- Las diez notas ficticias se usaron en el desarrollo y no son una prueba independiente. Falta revisar etiquetas y la versión exacta del catálogo antes de producir métricas de precisión/recall/F1.
- No se ha probado aquí Ollama ni OpenAI contra servidores reales; se validaron las llamadas y respuestas mediante mocks. Las salidas reales deben registrarse en el equipo de desarrollo.
- La interfaz con Streamlit y el informe por fases CRISP-ML(Q) siguen pendientes.
