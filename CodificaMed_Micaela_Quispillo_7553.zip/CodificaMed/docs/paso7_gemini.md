# Paso 7. Proveedor externo Gemini API

Este paso extiende el proyecto del paso 6. Mantiene Ollama y OpenAI y añade Gemini como proveedor externo. Su conexión utiliza HTTPS mediante `requests` y la ruta `models/{modelo}:generateContent`, con salida JSON estructurada. Todos los proveedores pasan por `src/providers/validacion.py`.

## Configuración de credenciales

1. Entra en Google AI Studio: https://aistudio.google.com/api-keys
2. Copia la clave ya creada para tu proyecto (no necesitas crear una clave nueva si ya la tienes).
3. En el archivo `.env` **existente** de CodificaMed cambia o añade, sin comillas:

```ini
LLM_PROVIDER=gemini
GEMINI_API_KEY=tu_clave_privada
GEMINI_MODEL=gemini-3.5-flash-lite
```

No pegues claves en el chat, capturas, consola, código o repositorios. El archivo `.env.example` está diseñado para compartir la configuración sin secretos; **no sobrescribas el archivo `.env` actual**. La clave no viaja en la URL, sino en la cabecera `x-goog-api-key` mediante HTTPS.

Los modelos Google AI Studio en nivel gratuito tienen cuotas variables por proyecto/modelo. Consultar: https://ai.google.dev/gemini-api/docs/rate-limits y https://ai.google.dev/gemini-api/docs/pricing. El nivel gratuito puede utilizar contenido para mejorar servicios de Google: **no envíes historias clínicas reales ni datos personales**.

## Instalación del parche sin duplicar el modelo de embeddings

Esta actualización se entrega como un ZIP parcial. **Extrae el contenido dentro de la carpeta CodificaMed que ya está funcionando**, reemplazando los archivos incluidos. No extraigas todo el proyecto de cero: así mantienes la unión `models_cache` que apunta a la caché del paso 5 y evitas descargas de 471 MB.

El parche no contiene `.env`, modelos ni cachés, y no necesita instalar dependencias nuevas.

## Pruebas locales (sin usar la API)

```powershell
python -m unittest discover -s tests -p "test_*.py" -v
python .\scripts\verificar_proveedores.py --proveedor gemini
```

En la primera prueba se esperan **63 pruebas correctas** en conjunto. `verificar_proveedores.py` solo confirma que hay una clave configurada; no comprueba si tiene cuota ni ejecuta inferencia.

## Primera inferencia real (consume cuota de Gemini)

```powershell
python .\scripts\demo_proveedores.py --proveedor gemini --sin-embeddings --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

Si esa prueba termina, ejecuta el mismo ejemplo con embeddings:

```powershell
python .\scripts\demo_proveedores.py --proveedor gemini --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

Ejecuta comparativamente el mismo texto con Ollama:

```powershell
python .\scripts\demo_proveedores.py --proveedor ollama --texto "Se confirma hipertensión arterial esencial. Niega fiebre. Se descarta neumonía."
```

Registra para cada ejecución el modelo, duración total, candidatos, códigos, estado, evidencia y rechazados. La comparación con una sola nota es **funcional**, no una evaluación clínica. Para calcular precisión, recall y F1 falta construir y auditar un conjunto de prueba independiente.

## Errores típicos

- **HTTP 400**: modelo o formato JSON inválido.
- **HTTP 401/403**: revisar la clave, restricciones y habilitación de API.
- **HTTP 404**: modelo no disponible en el proyecto; revisar `GEMINI_MODEL`.
- **HTTP 429**: cuota agotada o límite de frecuencia del nivel gratuito; revisar límites en AI Studio. Evita repetir automáticamente peticiones.
- **Error de embeddings o disco**: comprueba que el `models_cache` vinculado al paso 5 sigue existiendo; no vuelvas a descargar el modelo en C:.

El informe debe indicar que el catálogo aún está pendiente de auditoría de versión y que los resultados son sugerencias para revisión humana. Las claves API se excluyen del repositorio.
