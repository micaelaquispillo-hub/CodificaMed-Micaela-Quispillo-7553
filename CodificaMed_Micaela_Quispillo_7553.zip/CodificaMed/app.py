"""Interfaz web de CodificaMed para notas clínicas exclusivamente ficticias.

Ejecutar: python -m streamlit run app.py
"""
from __future__ import annotations

from time import perf_counter

import pandas as pd
import streamlit as st

from src.providers.configuracion import cargar_configuracion
from src.providers.pipeline import analizar_nota
from src.ui_utilidades import exportar_csv_revision, preparar_revision, resumen_estados

EJEMPLO = (
    "Se confirma hipertensión arterial esencial. "
    "Niega fiebre. Se descarta neumonía."
)
NOMBRES_PROVEEDOR = {"ollama": "Ollama (local)", "gemini": "Gemini (API externa)", "openai": "OpenAI (API externa)"}


@st.cache_resource(show_spinner="Cargando embeddings y el índice semántico...")
def cargar_recursos_semanticos():
    """Reutiliza los modelos en memoria; lee models_cache sin copiar el directorio."""
    from src.retrieval.semantica import (
        MODELO_PREDETERMINADO, cargar_modelo, construir_o_cargar_indice
    )
    codificador = cargar_modelo(MODELO_PREDETERMINADO)
    indice, _ = construir_o_cargar_indice(codificador, MODELO_PREDETERMINADO)
    return codificador, indice


def mostrar_diagnosticos(items: list[dict], titulo: str, vacio: str) -> None:
    st.subheader(titulo)
    if not items:
        st.info(vacio)
        return
    for item in items:
        with st.container(border=True):
            st.markdown(f"**{item['codigo']} — {item['descripcion']}**")
            st.caption(f"Estado clínico: {item['estado']}")
            st.markdown("**Evidencia literal**")
            st.code(item["evidencia"], language=None, wrap_lines=True)


def mostrar_resultado(resultado: dict) -> None:
    st.divider()
    st.subheader("Resultado de la última ejecución")
    st.caption("Estos resultados corresponden a la nota y a la configuración usadas en la última ejecución.")
    resumen = resumen_estados(resultado)
    cols = st.columns(4)
    cols[0].metric("Confirmados", resumen["confirmados"])
    cols[1].metric("Otros estados", resumen["otros_estados"])
    cols[2].metric("Candidatos", resumen["candidatos"])
    cols[3].metric("Tiempo total", f"{st.session_state.get('tiempo_ui', 0):.2f} s")
    st.caption(
        f"Proveedor: {resultado.get('proveedor', '')} · Modelo: {resultado.get('modelo', '')} "
        f"· Tiempo interno del pipeline: {resultado.get('duracion_segundos', 0)} s"
    )
    if resultado.get("advertencia"):
        st.warning(resultado["advertencia"])

    tab_diagnosticos, tab_candidatos, tab_revision = st.tabs(
        ["Diagnósticos", "Candidatos recuperados", "Revisión humana"]
    )
    with tab_diagnosticos:
        mostrar_diagnosticos(
            resultado.get("confirmados", []), "Confirmados",
            "No se identificaron diagnósticos confirmados en esta ejecución."
        )
        mostrar_diagnosticos(
            resultado.get("para_revision", []), "Negados, descartados y otros estados",
            "No hay resultados adicionales para revisión."
        )
        rechazados = resultado.get("rechazados", [])
        if rechazados:
            with st.expander(f"Elementos rechazados por el validador ({len(rechazados)})"):
                st.dataframe(pd.DataFrame(rechazados), hide_index=True, width="stretch")
    with tab_candidatos:
        st.caption("Las similitudes son puntuaciones de recuperación, no probabilidades ni diagnósticos.")
        if resultado.get("candidatos"):
            st.dataframe(pd.DataFrame(resultado["candidatos"]), hide_index=True, width="stretch")
        else:
            st.info("No se recuperaron candidatos para la nota.")
    with tab_revision:
        st.info(
            "Marca «revisado» solo después de comprobar el código, su contexto y su evidencia. "
            "Marcar un registro no cambia automáticamente su estado clínico."
        )
        filas = preparar_revision(resultado)
        if not filas:
            st.info("No existen sugerencias para revisar.")
        else:
            tabla = st.data_editor(
                pd.DataFrame(filas),
                hide_index=True,
                width="stretch",
                num_rows="fixed",
                disabled=["codigo", "descripcion", "estado", "evidencia"],
                column_config={
                    "revisado": st.column_config.CheckboxColumn(
                        "Revisado manualmente", help="Marca después de revisar cada sugerencia"
                    )
                },
                key=f"revision_{st.session_state.get('numero_analisis', 0)}",
            )
            seleccionados = tabla.to_dict(orient="records")
            revisados = sum(bool(f.get("revisado", False)) for f in seleccionados)
            st.caption(f"{revisados} de {len(seleccionados)} registros marcados como revisados.")
            st.download_button(
                "Exportar registros revisados (CSV)",
                data=exportar_csv_revision(seleccionados, solo_revisados=True),
                file_name="codificamed_revision.csv",
                mime="text/csv",
                disabled=revisados == 0,
            )


def main() -> None:
    st.set_page_config(page_title="CodificaMed", page_icon="📋", layout="wide")
    st.title("CodificaMed")
    st.write("Codificación asistida CIE-10 de notas clínicas ficticias en español.")
    st.warning(
        "Prototipo académico. No ingresar datos de pacientes reales. "
        "Las sugerencias requieren validación humana y no constituyen un diagnóstico médico."
    )

    try:
        por_defecto = cargar_configuracion().nombre
    except ValueError:
        por_defecto = "ollama"
    opciones = list(NOMBRES_PROVEEDOR)
    indice_defecto = opciones.index(por_defecto) if por_defecto in opciones else 0

    with st.form("formulario_analisis"):
        nota = st.text_area("Nota clínica ficticia", value=EJEMPLO, height=170, max_chars=10000)
        a, b = st.columns(2)
        with a:
            proveedor = st.selectbox(
                "Proveedor", opciones, index=indice_defecto,
                format_func=lambda p: NOMBRES_PROVEEDOR[p]
            )
        with b:
            usar_embeddings = st.checkbox("Usar recuperación semántica (embeddings)", value=True)
        solo_ficticios = st.checkbox(
            "Confirmo que la nota es ficticia y no contiene datos personales reales."
        )
        enviar = st.form_submit_button("Analizar nota", type="primary")

    try:
        cfg = cargar_configuracion(proveedor)
        st.caption(f"Modelo configurado: {cfg.modelo}")
        if cfg.nombre in {"gemini", "openai"} and not cfg.clave:
            st.warning(f"Falta configurar la clave del proveedor {cfg.nombre} en el archivo .env.")
    except ValueError as exc:
        cfg = None
        st.error(str(exc))

    if enviar:
        if not solo_ficticios:
            st.error("Confirma que la nota es ficticia y no contiene información de pacientes reales.")
        elif not nota.strip():
            st.error("Escribe una nota clínica ficticia antes de analizar.")
        elif cfg is None:
            st.error("No hay una configuración válida del proveedor.")
        elif cfg.nombre in {"gemini", "openai"} and not cfg.clave:
            st.error("No se encontró la clave del proveedor en .env.")
        else:
            inicio = perf_counter()
            try:
                with st.spinner("Procesando nota y consultando el proveedor seleccionado..."):
                    argumentos = {}
                    if usar_embeddings:
                        codificador, indice = cargar_recursos_semanticos()
                        argumentos = {"codificador": codificador, "indice": indice}
                    resultado = analizar_nota(
                        nota, proveedor=proveedor,
                        usar_embeddings=usar_embeddings, **argumentos
                    )
                st.session_state["ultimo_resultado"] = resultado
                st.session_state["tiempo_ui"] = perf_counter() - inicio
                st.session_state["numero_analisis"] = st.session_state.get("numero_analisis", 0) + 1
                st.success("Análisis terminado. Revisa los resultados antes de aceptar cualquier código.")
            except (ValueError, RuntimeError) as exc:
                st.error(f"No se pudo completar el análisis: {exc}")
            except Exception:
                # Nunca mostrar rastros completos que puedan contener credenciales.
                st.error("Ocurrió un error no previsto. Comprueba la configuración y la terminal de VS Code.")

    if "ultimo_resultado" in st.session_state:
        mostrar_resultado(st.session_state["ultimo_resultado"])
    else:
        st.info("Ingresa una nota ficticia, selecciona el proveedor y presiona «Analizar nota».")

    st.divider()
    st.caption(
        "El índice semántico inicial contiene 28 códigos del vocabulario controlado; "
        "no cubre todo el catálogo CIE-10. Las etiquetas de evaluación aún están en revisión."
    )


if __name__ == "__main__":
    main()
